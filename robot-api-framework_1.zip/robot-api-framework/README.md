# Robot API Framework — Iron Mountain

## Structure

```
robot-api-framework/
├── config/
│   ├── qa.yml          ← default env
│   ├── dev.yml
│   ├── stg.yml
│   └── etg.yml
├── resources/
│   └── common_headers.resource   ← shared headers + add/remove keywords
├── tests/
│   └── reports/
│       └── reports_test.robot
├── results/            ← auto-generated Robot output
└── README.md
```

## Prerequisites

```bash
pip install robotframework robotframework-requests pyyaml
```

## Running Tests

### Default (QA env)
```bash
robot --outputdir results tests/
```

### Specific environment
```bash
robot --outputdir results -v ENV:dev tests/
robot --outputdir results -v ENV:stg tests/
robot --outputdir results -v ENV:etg tests/
```

### Pass token at runtime
```bash
robot --outputdir results -v ENV:qa -v TOKEN:eyJraWQ... tests/
```

### Run by tag
```bash
robot --outputdir results -i smoke tests/
robot --outputdir results -i GET tests/
robot --outputdir results -i negative tests/
```

## Common Headers

`common_headers.resource` exposes three keywords:

| Keyword | Purpose |
|---|---|
| `Build Common Headers` | Returns the base headers dict (auth, companyid, solutionid, etc.) |
| `Add Header` | Adds or overrides one header key in an existing dict |
| `Remove Header` | Removes one header key from an existing dict |

### Example usage in a test
```robot
${headers}=    Build Common Headers
${headers}=    Add Header      ${headers}    x-trace-id    abc-123
${headers}=    Remove Header   ${headers}    accept-language
```

## Config Files

Each `config/<env>.yml` holds:
```yaml
base_url:    https://...
company_id:  "208275"
solution_id: "2e814851-..."
user_id:     user@ironmountain.com
```

Token is intentionally **not** stored in config — always pass via `-v TOKEN:...` or set `${TOKEN}` in your CI environment variable.
