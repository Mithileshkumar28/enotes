*** Settings ***
Documentation       Reports API Test Suite
...                 ENV default : qa  — override: --variable ENV:dev|stg|etg
...                 TOKEN       : --variable TOKEN:your_bearer_token
...
...                 Test types in this file:
...                   [NORMAL]    — hand-written, explicit step-by-step
...                   [JSON DD]   — data-driven from test_data/json/reports_data.json
...                   [EXCEL DD]  — data-driven from test_data/excel/reports_data.xlsx

Library             RequestsLibrary
Library             Collections
Library             JSONLibrary
Library             OperatingSystem
Library             String
Resource            ../resources/common_headers.resource
Resource            ../resources/base_suite.resource
Resource            ../resources/assertions.resource
Resource            ../resources/logger.resource
Resource            ../resources/data_loader.resource

Suite Setup         Initialize Suite
Suite Teardown      Suite Teardown Handler
Test Teardown       Log    ── [${TEST STATUS}] ${TEST NAME} ──


*** Variables ***
${REPORTS_EP}    /phyrapi/companies/${COMPANY_ID}/reports


*** Test Cases ***

# ╔══════════════════════════════════════════════════════════════════╗
# ║  NORMAL TEST CASES — hand-written, explicit assertions           ║
# ╚══════════════════════════════════════════════════════════════════╝

[NORMAL] GET - Smoke Returns 200
    [Documentation]    Basic smoke: GET /reports returns 200 and non-empty body.
    [Tags]             reports    normal    smoke    GET
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}
    Log API Request    GET    ${url}    ${COMMON_HEADERS}
    ${resp}=           GET    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code          ${resp}    200
    Assert Response Not Empty   ${resp}


[NORMAL] GET - Response Is A JSON List
    [Documentation]    Response body must be a JSON array.
    [Tags]             reports    normal    regression    GET
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}
    Log API Request    GET    ${url}    ${COMMON_HEADERS}
    ${resp}=           GET    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code      ${resp}    200
    Assert Response Is List   ${resp}


[NORMAL] GET - With Added Custom Header
    [Documentation]    Adds x-request-id for this test only; does not mutate COMMON_HEADERS.
    [Tags]             reports    normal    regression    GET    custom-header
    ${local}=          Get Base Headers
    ${local}=          Add Header    ${local}    x-request-id    report-test-001
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}
    Log API Request    GET    ${url}    ${local}
    ${resp}=           GET    url=${url}    headers=${local}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    200


[NORMAL] GET - Without content-type Header
    [Documentation]    Removes content-type for this request only.
    [Tags]             reports    normal    regression    GET    custom-header
    ${local}=          Get Base Headers
    ${local}=          Remove Header    ${local}    content-type
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}
    Log API Request    GET    ${url}    ${local}
    ${resp}=           GET    url=${url}    headers=${local}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    200


[NORMAL] GET - Response Time Under 5000ms
    [Documentation]    Performance: response time must be under 5000ms.
    [Tags]             reports    normal    performance    GET
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}
    Log API Request    GET    ${url}    ${COMMON_HEADERS}
    ${resp}=           GET    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code      ${resp}    200
    Assert Response Time    ${resp}    5000


[NORMAL] GET - With Retry On Transient Failure
    [Documentation]    Retries up to 3 times with 2s delay on flaky network.
    [Tags]             reports    normal    regression    GET    retry
    ${resp}=           Wait Until Keyword Succeeds    3x    2s
    ...                Reports GET Request And Assert 200
    Log API Response   ${resp}


[NORMAL] POST - Create Report Valid Payload
    [Documentation]    POST with valid body. Expects 200 or 201.
    [Tags]             reports    normal    regression    POST
    ${body}=           Create Dictionary    reportName=Normal Test Report    reportType=CUSTOM
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}
    Log API Request    POST    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           POST    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code In    ${resp}    200    201


[NORMAL] POST - Missing reportName Returns 400
    [Documentation]    Negative: POST without reportName should return 400.
    [Tags]             reports    normal    negative    POST
    ${body}=           Create Dictionary    reportType=CUSTOM
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}
    Log API Request    POST    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           POST    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    400


[NORMAL] POST - Empty Body Returns 400
    [Documentation]    Negative: POST with empty body should return 400.
    [Tags]             reports    normal    negative    POST
    ${body}=           Create Dictionary
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}
    Log API Request    POST    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           POST    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    400


[NORMAL] PUT - Update Existing Report
    [Documentation]    PUT full update. Replace REPORT_ID_PLACEHOLDER with a real ID.
    [Tags]             reports    normal    regression    PUT
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}/REPORT_ID_PLACEHOLDER
    ${body}=           Create Dictionary    reportName=Updated By Normal Test    reportType=CUSTOM
    Log API Request    PUT    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           PUT    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code In    ${resp}    200    404


[NORMAL] PUT - Non-existent ID Returns 404
    [Documentation]    Negative: PUT on a non-existent report id should return 404.
    [Tags]             reports    normal    negative    PUT
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}/non-existent-id
    ${body}=           Create Dictionary    reportName=Ghost    reportType=CUSTOM
    Log API Request    PUT    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           PUT    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    404


[NORMAL] PATCH - Partial Update reportName
    [Documentation]    PATCH with one field. Replace REPORT_ID_PLACEHOLDER with real ID.
    [Tags]             reports    normal    regression    PATCH
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}/REPORT_ID_PLACEHOLDER
    ${body}=           Create Dictionary    reportName=Patched By Normal Test
    Log API Request    PATCH    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           PATCH    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code In    ${resp}    200    404


[NORMAL] PATCH - Empty Body Returns 400
    [Documentation]    Negative: PATCH with empty body should return 400.
    [Tags]             reports    normal    negative    PATCH
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}/REPORT_ID_PLACEHOLDER
    ${body}=           Create Dictionary
    Log API Request    PATCH    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           PATCH    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    400


[NORMAL] DELETE - Delete Report
    [Documentation]    DELETE report. Replace REPORT_ID_PLACEHOLDER with real ID.
    [Tags]             reports    normal    regression    DELETE
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}/REPORT_ID_PLACEHOLDER
    Log API Request    DELETE    ${url}    ${COMMON_HEADERS}
    ${resp}=           DELETE    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code In    ${resp}    200    404


[NORMAL] DELETE - Non-existent ID Returns 404
    [Documentation]    Negative: DELETE on a non-existent report id should return 404.
    [Tags]             reports    normal    negative    DELETE
    ${url}=            Set Variable    ${BASE_URL}${REPORTS_EP}/non-existent-id
    Log API Request    DELETE    ${url}    ${COMMON_HEADERS}
    ${resp}=           DELETE    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    404


# ╔══════════════════════════════════════════════════════════════════╗
# ║  DATA-DRIVEN — JSON SOURCE                                       ║
# ╚══════════════════════════════════════════════════════════════════╝

[JSON DD] GET Reports
    [Documentation]    Iterates all GET rows in reports_data.json.
    [Tags]             reports    json-dd    GET
    ${rows}=    Load JSON Test Data    reports_data.json    GET
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From JSON Row    ${row}
        ${exp}=         Get JSON Field    ${row}    expected_status    200
        ${max_ms}=      Get JSON Field    ${row}    max_response_ms    ${None}
        Log API Request    GET    ${url}    ${COMMON_HEADERS}    test_name=${row}[test_name]
        ${resp}=        GET    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        IF    $max_ms is not None
            Assert Response Time    ${resp}    ${max_ms}
        END
        Log    [JSON DD] PASS: ${row}[test_name]
    END


[JSON DD] POST Reports
    [Documentation]    Iterates all POST rows in reports_data.json.
    [Tags]             reports    json-dd    POST
    ${rows}=    Load JSON Test Data    reports_data.json    POST
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From JSON Row    ${row}
        ${exp}=         Get JSON Field    ${row}    expected_status    201
        ${body}=        Parse Body From JSON Row    ${row}
        Log API Request    POST    ${url}    ${COMMON_HEADERS}    ${body}    test_name=${row}[test_name]
        ${resp}=        POST    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        ${keys_csv}=    Get JSON Field    ${row}    expected_keys    ${EMPTY}
        Run Keyword If    '${keys_csv}' != '${EMPTY}'
        ...    Assert Response Has Keys From String    ${resp}    ${keys_csv}
        Log    [JSON DD] PASS: ${row}[test_name]
    END


[JSON DD] PUT Reports
    [Documentation]    Iterates all PUT rows in reports_data.json.
    [Tags]             reports    json-dd    PUT
    ${rows}=    Load JSON Test Data    reports_data.json    PUT
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From JSON Row    ${row}
        ${exp}=         Get JSON Field    ${row}    expected_status    200
        ${body}=        Parse Body From JSON Row    ${row}
        Log API Request    PUT    ${url}    ${COMMON_HEADERS}    ${body}    test_name=${row}[test_name]
        ${resp}=        PUT    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        Log    [JSON DD] PASS: ${row}[test_name]
    END


[JSON DD] PATCH Reports
    [Documentation]    Iterates all PATCH rows in reports_data.json.
    [Tags]             reports    json-dd    PATCH
    ${rows}=    Load JSON Test Data    reports_data.json    PATCH
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From JSON Row    ${row}
        ${exp}=         Get JSON Field    ${row}    expected_status    200
        ${body}=        Parse Body From JSON Row    ${row}
        Log API Request    PATCH    ${url}    ${COMMON_HEADERS}    ${body}    test_name=${row}[test_name]
        ${resp}=        PATCH    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        Log    [JSON DD] PASS: ${row}[test_name]
    END


[JSON DD] DELETE Reports
    [Documentation]    Iterates all DELETE rows in reports_data.json.
    [Tags]             reports    json-dd    DELETE
    ${rows}=    Load JSON Test Data    reports_data.json    DELETE
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From JSON Row    ${row}
        ${exp}=         Get JSON Field    ${row}    expected_status    200
        Log API Request    DELETE    ${url}    ${COMMON_HEADERS}    test_name=${row}[test_name]
        ${resp}=        DELETE    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        Log    [JSON DD] PASS: ${row}[test_name]
    END


# ╔══════════════════════════════════════════════════════════════════╗
# ║  DATA-DRIVEN — EXCEL SOURCE                                      ║
# ╚══════════════════════════════════════════════════════════════════╝

[EXCEL DD] GET Reports
    [Documentation]    Iterates all rows in reports_data.xlsx → sheet GET.
    [Tags]             reports    excel-dd    GET
    ${rows}=    Load Excel Test Data    reports_data.xlsx    GET
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From Excel Row    ${row}
        ${exp}=         Get Excel Field    ${row}    expected_status    200
        ${max_ms}=      Get Excel Field    ${row}    max_response_ms    ${None}
        Log API Request    GET    ${url}    ${COMMON_HEADERS}    test_name=${row}[test_name]
        ${resp}=        GET    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        IF    $max_ms is not None and str($max_ms) not in ['', 'None']
            Assert Response Time    ${resp}    ${max_ms}
        END
        Log    [EXCEL DD] PASS: ${row}[test_name]
    END


[EXCEL DD] POST Reports
    [Documentation]    Iterates all rows in reports_data.xlsx → sheet POST.
    [Tags]             reports    excel-dd    POST
    ${rows}=    Load Excel Test Data    reports_data.xlsx    POST
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From Excel Row    ${row}
        ${exp}=         Get Excel Field    ${row}    expected_status    201
        ${body}=        Parse Body From Excel Row    ${row}
        Log API Request    POST    ${url}    ${COMMON_HEADERS}    ${body}    test_name=${row}[test_name]
        ${resp}=        POST    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        ${keys_csv}=    Get Excel Field    ${row}    expected_keys    ${EMPTY}
        Run Keyword If    '${keys_csv}' != '${EMPTY}'
        ...    Assert Response Has Keys From String    ${resp}    ${keys_csv}
        Log    [EXCEL DD] PASS: ${row}[test_name]
    END


[EXCEL DD] PUT Reports
    [Documentation]    Iterates all rows in reports_data.xlsx → sheet PUT.
    [Tags]             reports    excel-dd    PUT
    ${rows}=    Load Excel Test Data    reports_data.xlsx    PUT
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From Excel Row    ${row}
        ${exp}=         Get Excel Field    ${row}    expected_status    200
        ${body}=        Parse Body From Excel Row    ${row}
        Log API Request    PUT    ${url}    ${COMMON_HEADERS}    ${body}    test_name=${row}[test_name]
        ${resp}=        PUT    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        Log    [EXCEL DD] PASS: ${row}[test_name]
    END


[EXCEL DD] PATCH Reports
    [Documentation]    Iterates all rows in reports_data.xlsx → sheet PATCH.
    [Tags]             reports    excel-dd    PATCH
    ${rows}=    Load Excel Test Data    reports_data.xlsx    PATCH
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From Excel Row    ${row}
        ${exp}=         Get Excel Field    ${row}    expected_status    200
        ${body}=        Parse Body From Excel Row    ${row}
        Log API Request    PATCH    ${url}    ${COMMON_HEADERS}    ${body}    test_name=${row}[test_name]
        ${resp}=        PATCH    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        Log    [EXCEL DD] PASS: ${row}[test_name]
    END


[EXCEL DD] DELETE Reports
    [Documentation]    Iterates all rows in reports_data.xlsx → sheet DELETE.
    [Tags]             reports    excel-dd    DELETE
    ${rows}=    Load Excel Test Data    reports_data.xlsx    DELETE
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From Excel Row    ${row}
        ${exp}=         Get Excel Field    ${row}    expected_status    200
        Log API Request    DELETE    ${url}    ${COMMON_HEADERS}    test_name=${row}[test_name]
        ${resp}=        DELETE    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        Log    [EXCEL DD] PASS: ${row}[test_name]
    END


*** Keywords ***

# ── Shared helpers used by both JSON DD and Excel DD loops ──────────

Build URL From JSON Row
    [Documentation]    Resolves endpoint from a JSON data row and prepends BASE_URL.
    [Arguments]        ${row}
    ${ep}=    Get JSON Field    ${row}    endpoint    /phyrapi/companies/${COMPANY_ID}/reports
    ${ep}=    Replace String    ${ep}    {company_id}    ${COMPANY_ID}
    RETURN    ${BASE_URL}${ep}


Parse Body From JSON Row
    [Documentation]    Parses the body field from a JSON data row into a dict.
    [Arguments]        ${row}
    ${body_str}=    Get JSON Field    ${row}    body    {}
    ${body}=        Evaluate    __import__('json').loads("""${body_str}""")
    RETURN          ${body}


Build URL From Excel Row
    [Documentation]    Resolves endpoint from an Excel data row and prepends BASE_URL.
    [Arguments]        ${row}
    ${ep}=    Get Excel Field    ${row}    endpoint    /phyrapi/companies/${COMPANY_ID}/reports
    ${ep}=    Replace String    ${ep}    {company_id}    ${COMPANY_ID}
    RETURN    ${BASE_URL}${ep}


Parse Body From Excel Row
    [Documentation]    Parses the body field from an Excel data row into a dict.
    [Arguments]        ${row}
    ${body_str}=    Get Excel Field    ${row}    body    {}
    ${body}=        Evaluate    __import__('json').loads("""${body_str}""")
    RETURN          ${body}


Reports GET Request And Assert 200
    [Documentation]    Helper for the retry test — performs GET and asserts 200.
    ${resp}=    GET
    ...         url=${BASE_URL}${REPORTS_EP}
    ...         headers=${COMMON_HEADERS}
    ...         expected_status=any
    Assert Status Code    ${resp}    200
    RETURN    ${resp}
