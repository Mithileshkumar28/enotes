*** Settings ***
Documentation       Orders API Test Suite
...                 ENV default : qa  — override: --variable ENV:dev|stg|etg
...                 TOKEN       : --variable TOKEN:your_bearer_token
...
...                 Test types in this file:
...                   [NORMAL]    — hand-written, explicit step-by-step
...                   [JSON DD]   — data-driven from test_data/json/orders_data.json
...                   [EXCEL DD]  — data-driven from test_data/excel/orders_data.xlsx

Library             RequestsLibrary
Library             Collections
Library             JSONLibrary
Library             OperatingSystem
Library             String
Resource            ../resources/common_headers.resource
Resource            ../resources/base_suite.resource
Resource            ../resources/assertions.resource
Resource            ../resources/logger.resource
Resource            ../resources/data_loader.resource

Suite Setup         Initialize Suite
Suite Teardown      Suite Teardown Handler
Test Teardown       Log    ── [${TEST STATUS}] ${TEST NAME} ──


*** Variables ***
${ORDERS_EP}    /phyrapi/companies/${COMPANY_ID}/orders


*** Test Cases ***

# ╔══════════════════════════════════════════════════════════════════╗
# ║  NORMAL TEST CASES — hand-written, explicit assertions           ║
# ╚══════════════════════════════════════════════════════════════════╝

[NORMAL] GET - Smoke Returns 200
    [Documentation]    Basic smoke: GET /orders returns 200 and non-empty body.
    [Tags]             orders    normal    smoke    GET
    ${url}=            Set Variable    ${BASE_URL}${ORDERS_EP}
    Log API Request    GET    ${url}    ${COMMON_HEADERS}
    ${resp}=           GET    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code          ${resp}    200
    Assert Response Not Empty   ${resp}


[NORMAL] GET - Response Is A JSON List
    [Documentation]    Response body must be a JSON array.
    [Tags]             orders    normal    regression    GET
    ${url}=            Set Variable    ${BASE_URL}${ORDERS_EP}
    Log API Request    GET    ${url}    ${COMMON_HEADERS}
    ${resp}=           GET    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code      ${resp}    200
    Assert Response Is List   ${resp}


[NORMAL] GET - With Added Custom Header
    [Documentation]    Adds x-request-id for this test only.
    [Tags]             orders    normal    regression    GET    custom-header
    ${local}=          Get Base Headers
    ${local}=          Add Header    ${local}    x-request-id    orders-test-001
    ${url}=            Set Variable    ${BASE_URL}${ORDERS_EP}
    Log API Request    GET    ${url}    ${local}
    ${resp}=           GET    url=${url}    headers=${local}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    200


[NORMAL] GET - Response Time Under 5000ms
    [Documentation]    Performance: response time must be under 5000ms.
    [Tags]             orders    normal    performance    GET
    ${url}=            Set Variable    ${BASE_URL}${ORDERS_EP}
    Log API Request    GET    ${url}    ${COMMON_HEADERS}
    ${resp}=           GET    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code      ${resp}    200
    Assert Response Time    ${resp}    5000


[NORMAL] GET - With Retry On Transient Failure
    [Documentation]    Retries up to 3 times with 2s delay.
    [Tags]             orders    normal    regression    GET    retry
    ${resp}=           Wait Until Keyword Succeeds    3x    2s
    ...                Orders GET Request And Assert 200
    Log API Response   ${resp}


[NORMAL] GET - Invalid Company Returns 403
    [Documentation]    Negative: invalid companyId in URL should return 403.
    [Tags]             orders    normal    negative    GET
    ${url}=            Set Variable    ${BASE_URL}/phyrapi/companies/999999/orders
    Log API Request    GET    ${url}    ${COMMON_HEADERS}
    ${resp}=           GET    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    403


[NORMAL] POST - Create Order Valid Payload
    [Documentation]    POST with valid body. Expects 200 or 201.
    [Tags]             orders    normal    regression    POST
    ${body}=           Create Dictionary    orderType=RETRIEVAL    description=Normal Test Order
    ${url}=            Set Variable    ${BASE_URL}${ORDERS_EP}
    Log API Request    POST    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           POST    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code In    ${resp}    200    201


[NORMAL] POST - Missing orderType Returns 400
    [Documentation]    Negative: POST without orderType should return 400.
    [Tags]             orders    normal    negative    POST
    ${body}=           Create Dictionary    description=No Type Order
    ${url}=            Set Variable    ${BASE_URL}${ORDERS_EP}
    Log API Request    POST    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           POST    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    400


[NORMAL] POST - Empty Body Returns 400
    [Documentation]    Negative: POST with empty body should return 400.
    [Tags]             orders    normal    negative    POST
    ${body}=           Create Dictionary
    ${url}=            Set Variable    ${BASE_URL}${ORDERS_EP}
    Log API Request    POST    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           POST    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    400


[NORMAL] PUT - Update Existing Order
    [Documentation]    PUT full update. Replace ORDER_ID_PLACEHOLDER with a real ID.
    [Tags]             orders    normal    regression    PUT
    ${url}=            Set Variable    ${BASE_URL}${ORDERS_EP}/ORDER_ID_PLACEHOLDER
    ${body}=           Create Dictionary    description=Updated By Normal Test
    Log API Request    PUT    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           PUT    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code In    ${resp}    200    404


[NORMAL] PUT - Non-existent ID Returns 404
    [Documentation]    Negative: PUT on a non-existent order id should return 404.
    [Tags]             orders    normal    negative    PUT
    ${url}=            Set Variable    ${BASE_URL}${ORDERS_EP}/non-existent-id
    ${body}=           Create Dictionary    description=Ghost Order
    Log API Request    PUT    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           PUT    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    404


[NORMAL] PATCH - Partial Update Status
    [Documentation]    PATCH with status field only. Replace ORDER_ID_PLACEHOLDER with real ID.
    [Tags]             orders    normal    regression    PATCH
    ${url}=            Set Variable    ${BASE_URL}${ORDERS_EP}/ORDER_ID_PLACEHOLDER
    ${body}=           Create Dictionary    status=CANCELLED
    Log API Request    PATCH    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           PATCH    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code In    ${resp}    200    404


[NORMAL] PATCH - Empty Body Returns 400
    [Documentation]    Negative: PATCH with empty body should return 400.
    [Tags]             orders    normal    negative    PATCH
    ${url}=            Set Variable    ${BASE_URL}${ORDERS_EP}/ORDER_ID_PLACEHOLDER
    ${body}=           Create Dictionary
    Log API Request    PATCH    ${url}    ${COMMON_HEADERS}    ${body}
    ${resp}=           PATCH    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    400


[NORMAL] DELETE - Delete Order
    [Documentation]    DELETE order. Replace ORDER_ID_PLACEHOLDER with a real ID.
    [Tags]             orders    normal    regression    DELETE
    ${url}=            Set Variable    ${BASE_URL}${ORDERS_EP}/ORDER_ID_PLACEHOLDER
    Log API Request    DELETE    ${url}    ${COMMON_HEADERS}
    ${resp}=           DELETE    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code In    ${resp}    200    404


[NORMAL] DELETE - Non-existent ID Returns 404
    [Documentation]    Negative: DELETE on a non-existent order id should return 404.
    [Tags]             orders    normal    negative    DELETE
    ${url}=            Set Variable    ${BASE_URL}${ORDERS_EP}/non-existent-id
    Log API Request    DELETE    ${url}    ${COMMON_HEADERS}
    ${resp}=           DELETE    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
    Log API Response   ${resp}
    Assert Status Code    ${resp}    404


# ╔══════════════════════════════════════════════════════════════════╗
# ║  DATA-DRIVEN — JSON SOURCE                                       ║
# ╚══════════════════════════════════════════════════════════════════╝

[JSON DD] GET Orders
    [Documentation]    Iterates all GET rows in orders_data.json.
    [Tags]             orders    json-dd    GET
    ${rows}=    Load JSON Test Data    orders_data.json    GET
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From JSON Row    ${row}
        ${exp}=         Get JSON Field    ${row}    expected_status    200
        ${max_ms}=      Get JSON Field    ${row}    max_response_ms    ${None}
        Log API Request    GET    ${url}    ${COMMON_HEADERS}    test_name=${row}[test_name]
        ${resp}=        GET    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        IF    $max_ms is not None
            Assert Response Time    ${resp}    ${max_ms}
        END
        Log    [JSON DD] PASS: ${row}[test_name]
    END


[JSON DD] POST Orders
    [Documentation]    Iterates all POST rows in orders_data.json.
    [Tags]             orders    json-dd    POST
    ${rows}=    Load JSON Test Data    orders_data.json    POST
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From JSON Row    ${row}
        ${exp}=         Get JSON Field    ${row}    expected_status    201
        ${body}=        Parse Body From JSON Row    ${row}
        Log API Request    POST    ${url}    ${COMMON_HEADERS}    ${body}    test_name=${row}[test_name]
        ${resp}=        POST    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        ${keys_csv}=    Get JSON Field    ${row}    expected_keys    ${EMPTY}
        Run Keyword If    '${keys_csv}' != '${EMPTY}'
        ...    Assert Response Has Keys From String    ${resp}    ${keys_csv}
        Log    [JSON DD] PASS: ${row}[test_name]
    END


[JSON DD] PUT Orders
    [Documentation]    Iterates all PUT rows in orders_data.json.
    [Tags]             orders    json-dd    PUT
    ${rows}=    Load JSON Test Data    orders_data.json    PUT
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From JSON Row    ${row}
        ${exp}=         Get JSON Field    ${row}    expected_status    200
        ${body}=        Parse Body From JSON Row    ${row}
        Log API Request    PUT    ${url}    ${COMMON_HEADERS}    ${body}    test_name=${row}[test_name]
        ${resp}=        PUT    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        Log    [JSON DD] PASS: ${row}[test_name]
    END


[JSON DD] PATCH Orders
    [Documentation]    Iterates all PATCH rows in orders_data.json.
    [Tags]             orders    json-dd    PATCH
    ${rows}=    Load JSON Test Data    orders_data.json    PATCH
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From JSON Row    ${row}
        ${exp}=         Get JSON Field    ${row}    expected_status    200
        ${body}=        Parse Body From JSON Row    ${row}
        Log API Request    PATCH    ${url}    ${COMMON_HEADERS}    ${body}    test_name=${row}[test_name]
        ${resp}=        PATCH    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        Log    [JSON DD] PASS: ${row}[test_name]
    END


[JSON DD] DELETE Orders
    [Documentation]    Iterates all DELETE rows in orders_data.json.
    [Tags]             orders    json-dd    DELETE
    ${rows}=    Load JSON Test Data    orders_data.json    DELETE
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From JSON Row    ${row}
        ${exp}=         Get JSON Field    ${row}    expected_status    200
        Log API Request    DELETE    ${url}    ${COMMON_HEADERS}    test_name=${row}[test_name]
        ${resp}=        DELETE    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        Log    [JSON DD] PASS: ${row}[test_name]
    END


# ╔══════════════════════════════════════════════════════════════════╗
# ║  DATA-DRIVEN — EXCEL SOURCE                                      ║
# ╚══════════════════════════════════════════════════════════════════╝

[EXCEL DD] GET Orders
    [Documentation]    Iterates all rows in orders_data.xlsx → sheet GET.
    [Tags]             orders    excel-dd    GET
    ${rows}=    Load Excel Test Data    orders_data.xlsx    GET
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From Excel Row    ${row}
        ${exp}=         Get Excel Field    ${row}    expected_status    200
        ${max_ms}=      Get Excel Field    ${row}    max_response_ms    ${None}
        Log API Request    GET    ${url}    ${COMMON_HEADERS}    test_name=${row}[test_name]
        ${resp}=        GET    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        IF    $max_ms is not None and str($max_ms) not in ['', 'None']
            Assert Response Time    ${resp}    ${max_ms}
        END
        Log    [EXCEL DD] PASS: ${row}[test_name]
    END


[EXCEL DD] POST Orders
    [Documentation]    Iterates all rows in orders_data.xlsx → sheet POST.
    [Tags]             orders    excel-dd    POST
    ${rows}=    Load Excel Test Data    orders_data.xlsx    POST
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From Excel Row    ${row}
        ${exp}=         Get Excel Field    ${row}    expected_status    201
        ${body}=        Parse Body From Excel Row    ${row}
        Log API Request    POST    ${url}    ${COMMON_HEADERS}    ${body}    test_name=${row}[test_name]
        ${resp}=        POST    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        ${keys_csv}=    Get Excel Field    ${row}    expected_keys    ${EMPTY}
        Run Keyword If    '${keys_csv}' != '${EMPTY}'
        ...    Assert Response Has Keys From String    ${resp}    ${keys_csv}
        Log    [EXCEL DD] PASS: ${row}[test_name]
    END


[EXCEL DD] PUT Orders
    [Documentation]    Iterates all rows in orders_data.xlsx → sheet PUT.
    [Tags]             orders    excel-dd    PUT
    ${rows}=    Load Excel Test Data    orders_data.xlsx    PUT
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From Excel Row    ${row}
        ${exp}=         Get Excel Field    ${row}    expected_status    200
        ${body}=        Parse Body From Excel Row    ${row}
        Log API Request    PUT    ${url}    ${COMMON_HEADERS}    ${body}    test_name=${row}[test_name]
        ${resp}=        PUT    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        Log    [EXCEL DD] PASS: ${row}[test_name]
    END


[EXCEL DD] PATCH Orders
    [Documentation]    Iterates all rows in orders_data.xlsx → sheet PATCH.
    [Tags]             orders    excel-dd    PATCH
    ${rows}=    Load Excel Test Data    orders_data.xlsx    PATCH
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From Excel Row    ${row}
        ${exp}=         Get Excel Field    ${row}    expected_status    200
        ${body}=        Parse Body From Excel Row    ${row}
        Log API Request    PATCH    ${url}    ${COMMON_HEADERS}    ${body}    test_name=${row}[test_name]
        ${resp}=        PATCH    url=${url}    headers=${COMMON_HEADERS}    json=${body}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        Log    [EXCEL DD] PASS: ${row}[test_name]
    END


[EXCEL DD] DELETE Orders
    [Documentation]    Iterates all rows in orders_data.xlsx → sheet DELETE.
    [Tags]             orders    excel-dd    DELETE
    ${rows}=    Load Excel Test Data    orders_data.xlsx    DELETE
    FOR    ${row}    IN    @{rows}
        ${url}=         Build URL From Excel Row    ${row}
        ${exp}=         Get Excel Field    ${row}    expected_status    200
        Log API Request    DELETE    ${url}    ${COMMON_HEADERS}    test_name=${row}[test_name]
        ${resp}=        DELETE    url=${url}    headers=${COMMON_HEADERS}    expected_status=any
        Log API Response    ${resp}    test_name=${row}[test_name]
        Assert Status Code    ${resp}    ${exp}
        Log    [EXCEL DD] PASS: ${row}[test_name]
    END


*** Keywords ***

Build URL From JSON Row
    [Documentation]    Resolves endpoint from a JSON data row and prepends BASE_URL.
    [Arguments]        ${row}
    ${ep}=    Get JSON Field    ${row}    endpoint    /phyrapi/companies/${COMPANY_ID}/orders
    ${ep}=    Replace String    ${ep}    {company_id}    ${COMPANY_ID}
    RETURN    ${BASE_URL}${ep}


Parse Body From JSON Row
    [Documentation]    Parses the body field from a JSON data row into a dict.
    [Arguments]        ${row}
    ${body_str}=    Get JSON Field    ${row}    body    {}
    ${body}=        Evaluate    __import__('json').loads("""${body_str}""")
    RETURN          ${body}


Build URL From Excel Row
    [Documentation]    Resolves endpoint from an Excel data row and prepends BASE_URL.
    [Arguments]        ${row}
    ${ep}=    Get Excel Field    ${row}    endpoint    /phyrapi/companies/${COMPANY_ID}/orders
    ${ep}=    Replace String    ${ep}    {company_id}    ${COMPANY_ID}
    RETURN    ${BASE_URL}${ep}


Parse Body From Excel Row
    [Documentation]    Parses the body field from an Excel data row into a dict.
    [Arguments]        ${row}
    ${body_str}=    Get Excel Field    ${row}    body    {}
    ${body}=        Evaluate    __import__('json').loads("""${body_str}""")
    RETURN          ${body}


Orders GET Request And Assert 200
    [Documentation]    Helper for retry test — performs GET and asserts 200.
    ${resp}=    GET
    ...         url=${BASE_URL}${ORDERS_EP}
    ...         headers=${COMMON_HEADERS}
    ...         expected_status=any
    Assert Status Code    ${resp}    200
    RETURN    ${resp}
