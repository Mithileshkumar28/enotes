"""
robot_excel_loader.py
─────────────────────────────────────────────────────────────────────
Python helper imported by data_loader.resource to read Excel (.xlsx)
test data files via openpyxl.

Place this file in the PROJECT ROOT so Robot Framework can import it
with:  Evaluate  __import__('robot_excel_loader').load_excel_sheet(...)

Sheet layout:
  Row 1  — column headers  (e.g. test_name, endpoint, body, expected_status)
  Row 2+ — one test case per row

Sheets should be named after HTTP methods: GET, POST, PUT, PATCH, DELETE
"""

import json
import openpyxl


def load_excel_sheet(filepath: str, sheet_name: str) -> list:
    """
    Reads the named sheet from an .xlsx file.

    Returns:
        list[dict] — one dict per non-empty data row,
                     keys taken from Row 1 (headers).

    Raises:
        ValueError  — if the sheet name does not exist in the workbook.
        FileNotFoundError — if the file path does not exist.
    """
    wb = openpyxl.load_workbook(filepath, data_only=True)

    if sheet_name not in wb.sheetnames:
        available = ", ".join(wb.sheetnames)
        raise ValueError(
            f"Sheet '{sheet_name}' not found in '{filepath}'. "
            f"Available sheets: {available}"
        )

    ws = wb[sheet_name]
    all_rows = list(ws.iter_rows(values_only=True))

    if not all_rows:
        return []

    # Row 1 = headers; strip whitespace, fill blanks with col_N
    headers = [
        str(h).strip() if h is not None else f"col_{i}"
        for i, h in enumerate(all_rows[0])
    ]

    result = []
    for row in all_rows[1:]:
        # skip fully empty rows
        if all(cell is None for cell in row):
            continue
        row_dict = {}
        for header, cell in zip(headers, row):
            # keep None as empty string for Robot compatibility
            row_dict[header] = "" if cell is None else cell
        result.append(row_dict)

    return result


def parse_body(body_str: str):
    """
    Parses a JSON string from an Excel cell into a Python dict.

    Returns:
        dict  — parsed JSON object
        None  — if the string is empty or invalid JSON
    """
    if not body_str or str(body_str).strip() == "":
        return None
    try:
        return json.loads(str(body_str))
    except json.JSONDecodeError:
        return None
