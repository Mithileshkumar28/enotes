# Robot API Framework

A clean, scalable Robot Framework API test suite for Iron Mountain Insight APIs.
Supports normal hand-written tests, JSON data-driven tests, and Excel data-driven tests.

---

## Project Structure

```
robot-api-framework/
├── config/
│   └── config.yml                        # env configs: dev | qa | stg | etg
│
├── resources/
│   ├── common_headers.resource           # base headers + Add Header / Remove Header
│   ├── base_suite.resource               # shared Settings, Variables, Initialize Suite
│   ├── assertions.resource               # all response validation utilities
│   ├── logger.resource                   # API request/response + validation logging
│   └── data_loader.resource              # Load JSON / Load Excel keywords
│
├── test_data/
│   ├── json/
│   │   ├── reports_data.json             # reports test data by HTTP method key
│   │   └── orders_data.json              # orders test data by HTTP method key
│   └── excel/
│       ├── reports_data.xlsx             # reports test data — one sheet per method
│       └── orders_data.xlsx              # orders test data — one sheet per method
│
├── tests/
│   ├── reports_api.robot                 # Reports API — normal + JSON DD + Excel DD
│   └── orders_api.robot                  # Orders API  — normal + JSON DD + Excel DD
│
├── results/
│   └── logs/
│       ├── api_responses/                # per-request logs (request + response)
│       └── validation/                   # per-assertion PASS/FAIL logs
│
├── .github/workflows/
│   └── robot-tests.yml                   # GitHub Actions CI/CD pipeline
│
├── robot_excel_loader.py                 # Python helper for Excel reading
├── Makefile                              # run shortcuts
└── requirements.txt
```

---

## Setup

```bash
pip install -r requirements.txt
```

---

## Run Tests

### Using Make (recommended)

```bash
# Install
make install

# All tests on QA (default)
make qa TOKEN=your_bearer_token

# All tests on DEV
make dev TOKEN=your_bearer_token

# All tests on STG
make stg TOKEN=your_bearer_token

# Only smoke tests
make smoke TOKEN=your_bearer_token

# Only regression tests
make regression TOKEN=your_bearer_token

# Only negative tests
make negative TOKEN=your_bearer_token

# Only performance tests
make performance TOKEN=your_bearer_token

# Only Reports suite
make reports TOKEN=your_bearer_token

# Only Orders suite
make orders TOKEN=your_bearer_token

# Filter by test type
make normal    TOKEN=your_bearer_token   # hand-written tests only
make json-dd   TOKEN=your_bearer_token   # JSON data-driven only
make excel-dd  TOKEN=your_bearer_token   # Excel data-driven only

# Filter by HTTP method
make get    TOKEN=your_bearer_token
make post   TOKEN=your_bearer_token
make put    TOKEN=your_bearer_token
make patch  TOKEN=your_bearer_token
make delete TOKEN=your_bearer_token
```

### Using robot directly

```bash
# QA (default env)
robot --variable TOKEN:your_token --outputdir results tests/

# Switch env
robot --variable ENV:dev --variable TOKEN:your_token --outputdir results tests/

# Filter by tag
robot --variable TOKEN:your_token --include smoke --outputdir results tests/
robot --variable TOKEN:your_token --include regression --outputdir results tests/
robot --variable TOKEN:your_token --include json-dd --outputdir results tests/
robot --variable TOKEN:your_token --include excel-dd --outputdir results tests/
robot --variable TOKEN:your_token --include GET --outputdir results tests/

# Run single suite
robot --variable TOKEN:your_token --outputdir results tests/reports_api.robot
```

---

## Test Types

Each `.robot` file contains three categories of tests:

| Prefix | Source | Description |
|---|---|---|
| `[NORMAL]` | Inline in `.robot` | Hand-written, explicit step-by-step assertions |
| `[JSON DD]` | `test_data/json/` | Data-driven, one row per test case in JSON |
| `[EXCEL DD]` | `test_data/excel/` | Data-driven, one row per test case in Excel sheet |

---

## Tags Reference

| Tag | Selects |
|---|---|
| `smoke` | Basic sanity tests |
| `regression` | Full regression suite |
| `negative` | Error/negative scenarios |
| `performance` | Response time checks |
| `normal` | All hand-written tests |
| `json-dd` | All JSON data-driven tests |
| `excel-dd` | All Excel data-driven tests |
| `GET` `POST` `PUT` `PATCH` `DELETE` | By HTTP method |
| `reports` `orders` | By API domain |
| `custom-header` | Header manipulation tests |
| `retry` | Retry-on-failure tests |

---

## Logs

Every request and response is logged automatically under `results/logs/`:

- `results/logs/api_responses/` — `{test_name}_{timestamp}.log` with method, URL, masked headers, body, status code, response time, response body
- `results/logs/validation/` — `{test_name}_{timestamp}.log` with field, expected, actual, PASS/FAIL per assertion

The Bearer token is **always masked** in log files.

---

## Test Data

### JSON format (`test_data/json/`)

```json
{
  "GET":    [ { "test_name": "...", "endpoint": "...", "expected_status": 200 }, ... ],
  "POST":   [ { "test_name": "...", "endpoint": "...", "body": "{...}", "expected_status": 201 }, ... ],
  "PUT":    [ ... ],
  "PATCH":  [ ... ],
  "DELETE": [ ... ]
}
```

### Excel format (`test_data/excel/`)

One sheet per HTTP method (`GET`, `POST`, `PUT`, `PATCH`, `DELETE`).
Row 1 = column headers. Row 2+ = one test case per row.

Columns: `test_name`, `endpoint`, `body` (JSON string), `expected_status`, `expected_keys` (comma-separated), `max_response_ms`, `tags`

---

## Header Management

```robot
# Suite-wide shared headers (set once in Suite Setup)
${COMMON_HEADERS}

# Add a header for one test only
${local}=  Get Base Headers
${local}=  Add Header    ${local}    x-request-id    abc-123

# Remove a header for one test only
${local}=  Get Base Headers
${local}=  Remove Header    ${local}    content-type
```

---

## CI/CD (GitHub Actions)

Token is stored as a GitHub Secret named `ROBOT_API_TOKEN`.

Trigger manually from Actions tab with env and tag selection, or automatically on push/PR to `main` / `develop`.

```
Settings → Secrets and variables → Actions → New repository secret
Name:  ROBOT_API_TOKEN
Value: your_bearer_token
```
