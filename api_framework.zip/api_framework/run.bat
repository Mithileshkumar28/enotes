@echo off
:: ═══════════════════════════════════════════════════════════════════════════
::  run.bat — API Test Framework Runner
::  Usage:
::    run.bat                         → runs qa smoke+regression+integration
::    run.bat qa                      → explicit qa
::    run.bat dev                     → dev environment
::    run.bat prod                    → prod (smoke only, enforced by YAML)
::    run.bat qa smoke                → qa + smoke suite only
::    run.bat qa regression           → qa + regression suite only
::    run.bat qa integration          → qa + integration suite only
:: ═══════════════════════════════════════════════════════════════════════════

:: ── 1. Environment (default: qa) ──────────────────────────────────────────
SET ENV=%1
IF "%ENV%"=="" SET ENV=qa

:: Validate env
IF NOT "%ENV%"=="dev" IF NOT "%ENV%"=="qa" IF NOT "%ENV%"=="prod" (
    echo [ERROR] Unknown environment: %ENV%
    echo         Valid values: dev ^| qa ^| prod
    EXIT /B 1
)

:: Export so config_loader picks it up
SET FRAMEWORK_ENV=%ENV%
echo [run.bat] Environment: %FRAMEWORK_ENV%

:: ── 2. Suite filter (default: all) ────────────────────────────────────────
SET SUITE=%2
IF "%SUITE%"=="" SET SUITE=all

:: ── 3. Output dir ─────────────────────────────────────────────────────────
SET OUTPUT_DIR=reports\%ENV%
IF NOT EXIST %OUTPUT_DIR% mkdir %OUTPUT_DIR%

:: ── 4. Build robot command ─────────────────────────────────────────────────
SET RF_CMD=python -m robot --outputdir %OUTPUT_DIR% --loglevel DEBUG

IF "%SUITE%"=="smoke" (
    SET RF_CMD=%RF_CMD% tests\smoke\
    GOTO RUN
)
IF "%SUITE%"=="regression" (
    SET RF_CMD=%RF_CMD% tests\regression\
    GOTO RUN
)
IF "%SUITE%"=="integration" (
    SET RF_CMD=%RF_CMD% tests\integration\
    GOTO RUN
)

:: prod → smoke only (regardless of SUITE arg)
IF "%ENV%"=="prod" (
    echo [run.bat] PROD: running smoke suite only
    SET RF_CMD=%RF_CMD% tests\smoke\
    GOTO RUN
)

:: default: all suites
SET RF_CMD=%RF_CMD% tests\

:RUN
echo [run.bat] Command: %RF_CMD%
echo ──────────────────────────────────────────────────────────────────────────
%RF_CMD%
SET EXIT_CODE=%ERRORLEVEL%

echo ──────────────────────────────────────────────────────────────────────────
echo [run.bat] Reports saved to: %OUTPUT_DIR%\
echo [run.bat] Exit code: %EXIT_CODE%
EXIT /B %EXIT_CODE%
