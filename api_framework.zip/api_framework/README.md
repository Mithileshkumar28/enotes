# API Test Framework

Robot Framework API testing framework with clean layering, dynamic waits, and single-point environment control.

---

## Quick Start

```bash
# 1. Install dependencies (once)
pip install -r requirements.txt

# 2. Run against QA (default)
run.bat

# 3. Run against a specific env
run.bat dev
run.bat prod

# 4. Run a specific suite
run.bat qa smoke
run.bat qa regression
run.bat qa integration
```

---

## Environment Control — Change ONE Place

Environment is set via the `FRAMEWORK_ENV` variable.

**Priority (highest → lowest):**
1. OS / CI env var: `set FRAMEWORK_ENV=prod`
2. Default in `config/config_loader.py`: `_DEFAULT_ENV = "qa"`

`run.bat` sets it automatically from its first argument.
Every YAML value (base_url, timeout, retries, log level) flows from the active config — no file needs editing except the YAML.

| Env  | Log Level | Timeout | Retries | Suites             |
|------|-----------|---------|---------|-------------------|
| dev  | DEBUG     | 10s     | 2       | smoke+reg+int      |
| qa   | INFO      | 30s     | 3       | smoke+reg+int      |
| prod | WARNING   | 60s     | 3       | smoke only         |

---

## Project Structure

```
api_framework/
├── config/
│   ├── config_loader.py   ← SINGLE source of truth; reads FRAMEWORK_ENV
│   ├── dev.yaml
│   ├── qa.yaml            ← default
│   └── prod.yaml
│
├── core/
│   ├── token_manager.py   ← fetch + cache OAuth2 token; auto-refresh on 401
│   ├── header_manager.py  ← common headers (add/remove headers HERE only)
│   ├── request_manager.py ← assemble full request dict
│   ├── payload_builder.py ← fluent JSON body builder
│   └── api_client.py      ← execute + dynamic wait + APIResponse
│
├── utilities/
│   ├── logger.py          ← setup_logging(); reads level from YAML
│   ├── json_utils.py      ← load/save/extract/diff/flatten
│   ├── retry.py           ← @with_retry decorator + retry_call()
│   ├── faker_utils.py     ← random test data
│   ├── db_utils.py        ← DB helpers (defined, NOT active by default)
│   ├── schema_validator.py
│   └── response_validator.py
│
├── resources/
│   ├── auth_keywords.robot
│   ├── common_keywords.robot
│   └── user_keywords.robot
│
├── keywords/
│   └── ApiKeywords.py     ← Robot ↔ Python bridge (one library)
│
├── testdata/
│   ├── payloads/create_user.json
│   └── schemas/user.json
│
├── tests/
│   ├── smoke/             TC_S001–TC_S005
│   ├── regression/        TC_R001–TC_R015
│   └── integration/       TC_I001–TC_I005
│
├── reports/               ← HTML + log output per env
├── requirements.txt
└── run.bat
```

---

## Token Flow

```
Test keyword
   └─► ApiKeywords
         └─► APIClient.send()
               └─► RequestManager.build()
                     └─► HeaderManager.get_headers()
                           └─► TokenManager.get_token()
                                 ├── cached & valid → return token
                                 └── expired/missing → POST /auth/token → cache → return
```

On **401**, `APIClient` calls `token_manager.invalidate()` and retries once automatically.

---

## Adding / Removing Headers

Open `core/header_manager.py` → `_base_headers()`.
That dict is the one and only place headers are defined. All tests pick up the change instantly.

```python
def _base_headers(self) -> dict:
    token = self._token_manager.get_token()
    return {
        "Authorization":   f"Bearer {token}",
        "Content-Type":    "application/json",
        "Accept":          "application/json",
        "X-Request-Id":    str(uuid.uuid4()),
        "Accept-Language": "en-US",
        # ← add new headers here
    }
```

---

## Dynamic Wait

```robotframework
# Wait until status code is 200 (polls every 3s, max 60s)
${response}=    Wait Until Status Code Is    /jobs/42    200    timeout=60    interval=3

# Wait until a response field reaches a value
${response}=    Wait Until Field Value Is    /users/42    data.status    active    timeout=30
```

---

## Payload Builder

```robotframework
# From file with override
${payload}=    Build Payload From File    testdata/payloads/create_user.json
...            overrides={"email": "new@example.com"}

# From scratch
${payload}=    Build Payload    first_name=Alice    role=admin
```

---

## Database (when needed)

`db_utils.py` is **defined but not wired** to any keyword or test.
To use it: set `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` env vars, then instantiate `DBUtils()` in a keyword.

---

## Logs

Logs are written to both console and `reports/<env>.log`.
Log level is controlled entirely by the active YAML config — no code change needed.
