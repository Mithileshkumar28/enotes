"""
core/payload_builder.py
────────────────────────
Fluent (method-chaining) builder for JSON request bodies.

Usage:
    body = (
        PayloadBuilder()
        .set("name", "Alice")
        .set("email", "alice@example.com")
        .set("role", "admin")
        .build()
    )
    # → {"name": "Alice", "email": "alice@example.com", "role": "admin"}

    # Load from file, then override one key:
    body = PayloadBuilder.from_file("testdata/payloads/create_user.json") \
               .set("email", "override@example.com") \
               .build()
"""

import json
from copy import deepcopy
from pathlib import Path

from utilities.logger import get_logger

logger = get_logger(__name__)


class PayloadBuilder:
    """
    Immutable-style fluent builder for JSON payloads.
    Each set() / remove() / merge() returns self to allow chaining.
    Call build() to get the final dict.
    """

    def __init__(self, initial: dict | None = None):
        self._data: dict = deepcopy(initial) if initial else {}

    # ── factory ────────────────────────────────────────────────────────────

    @classmethod
    def from_file(cls, path: str) -> "PayloadBuilder":
        """Load a JSON file as the starting payload."""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"[PayloadBuilder] Payload file not found: {path}")
        with open(p, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        logger.debug("PayloadBuilder loaded from file: %s", path)
        return cls(initial=data)

    # ── fluent API ─────────────────────────────────────────────────────────

    def set(self, key: str, value) -> "PayloadBuilder":
        """Add or overwrite a top-level key."""
        self._data[key] = value
        return self

    def set_nested(self, *keys: str, value) -> "PayloadBuilder":
        """
        Set a deeply nested key.
        set_nested("address", "city", value="Mumbai")
        → {"address": {"city": "Mumbai"}}
        """
        d = self._data
        for key in keys[:-1]:
            d = d.setdefault(key, {})
        d[keys[-1]] = value
        return self

    def remove(self, key: str) -> "PayloadBuilder":
        """Remove a key (silently ignored if absent)."""
        self._data.pop(key, None)
        return self

    def merge(self, extra: dict) -> "PayloadBuilder":
        """Shallow-merge a dict on top of the current payload."""
        self._data.update(extra)
        return self

    def build(self) -> dict:
        """Return a deep-copy of the built payload dict."""
        payload = deepcopy(self._data)
        logger.debug("PayloadBuilder.build() → keys: %s", list(payload.keys()))
        return payload

    def build_json(self) -> str:
        """Return the payload serialised as a JSON string."""
        return json.dumps(self.build(), indent=2)

    def __repr__(self) -> str:
        return f"<PayloadBuilder keys={list(self._data.keys())}>"
