"""
core/header_manager.py
───────────────────────
Sits between the test layer and TokenManager.
Returns a clean, ready-to-use headers dict for every request.

Design goal:
  • Add / remove a header in ONE place here → all tests pick it up.
  • Tests never construct headers manually.

Usage:
    hm = HeaderManager()
    headers = hm.get_headers()
    headers = hm.get_headers(extra={"X-Correlation-Id": "abc-123"})
    headers = hm.get_headers(exclude=["Accept-Language"])
"""

import uuid
import logging

from core.token_manager import TokenManager
from utilities.logger import get_logger

logger = get_logger(__name__)


class HeaderManager:
    """
    Builds the common HTTP headers for every API request.

    Base headers (returned by default)
    ───────────────────────────────────
    Authorization   : Bearer <token>        ← from TokenManager
    Content-Type    : application/json
    Accept          : application/json
    X-Request-Id    : <uuid4>               ← unique per call for traceability
    Accept-Language : en-US

    To add a permanent header → add it to _base_headers().
    To remove one             → delete it from _base_headers().
    To add per-call extras    → pass extra={} to get_headers().
    To suppress specific keys → pass exclude=[] to get_headers().
    """

    def __init__(self, token_manager: TokenManager | None = None):
        self._token_manager = token_manager or TokenManager()

    # ── public ─────────────────────────────────────────────────────────────

    def get_headers(
        self,
        extra: dict | None = None,
        exclude: list | None = None,
    ) -> dict:
        """
        Return the merged headers dict.

        Args:
            extra   : Additional headers to merge on top of the base set.
            exclude : List of header keys to remove from the final dict.

        Returns:
            dict ready to pass as `headers=` to requests / APIClient.
        """
        headers = self._base_headers()

        if extra:
            headers.update(extra)
            logger.debug("Headers — added extras: %s", list(extra.keys()))

        if exclude:
            for key in exclude:
                headers.pop(key, None)
            logger.debug("Headers — excluded: %s", exclude)

        logger.debug("Final headers (keys): %s", list(headers.keys()))
        return headers

    def get_headers_without_auth(self) -> dict:
        """
        Returns base headers minus the Authorization header.
        Useful for testing unauthenticated endpoints.
        """
        return self.get_headers(exclude=["Authorization"])

    def get_multipart_headers(self) -> dict:
        """
        Headers for multipart/form-data uploads.
        Content-Type is intentionally omitted so requests sets the boundary.
        """
        return self.get_headers(exclude=["Content-Type"])

    # ── private ────────────────────────────────────────────────────────────

    def _base_headers(self) -> dict:
        """
        Central definition of all default headers.
        ── Add / remove headers HERE to affect the entire framework ──
        """
        token = self._token_manager.get_token()
        return {
            "Authorization":  f"Bearer {token}",
            "Content-Type":   "application/json",
            "Accept":         "application/json",
            "X-Request-Id":   str(uuid.uuid4()),
            "Accept-Language": "en-US",
        }
