"""
core/request_manager.py
────────────────────────
Builds a complete, validated request dictionary from its parts:
  method, endpoint, headers (via HeaderManager), params, body.

The result dict is passed directly into APIClient.send_request().

Usage:
    rm = RequestManager()
    req = rm.build(
        method   = "POST",
        endpoint = "/users",
        body     = {"name": "Alice", "email": "alice@example.com"},
    )
    # → {"method": "POST", "url": "https://qa-api.example.com/users",
    #    "headers": {...}, "json": {...}}
"""

import logging
from urllib.parse import urljoin

from config.config_loader import config
from core.header_manager import HeaderManager
from utilities.logger import get_logger

logger = get_logger(__name__)

_ALLOWED_METHODS = {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"}


class RequestManager:
    """
    Assembles a ready-to-execute request dict.
    Tests call build(); APIClient calls execute().
    """

    def __init__(self, header_manager: HeaderManager | None = None):
        self._header_manager = header_manager or HeaderManager()

    # ── public ─────────────────────────────────────────────────────────────

    def build(
        self,
        method: str,
        endpoint: str,
        body: dict | None = None,
        params: dict | None = None,
        extra_headers: dict | None = None,
        exclude_headers: list | None = None,
        auth: bool = True,
    ) -> dict:
        """
        Build and return the full request dict.

        Args:
            method          : HTTP method (GET, POST, …)
            endpoint        : Path relative to base_url, e.g. "/users/123"
            body            : JSON-serialisable dict for the request body.
            params          : Query-string parameters dict.
            extra_headers   : Additional headers merged on top of defaults.
            exclude_headers : Header keys to strip from the default set.
            auth            : If False, Authorization header is excluded.

        Returns:
            dict with keys: method, url, headers, json (optional), params (optional)
        """
        method = method.upper()
        if method not in _ALLOWED_METHODS:
            raise ValueError(f"[RequestManager] Unsupported HTTP method: '{method}'")

        url = self._build_url(endpoint)

        if auth:
            headers = self._header_manager.get_headers(
                extra=extra_headers,
                exclude=exclude_headers,
            )
        else:
            exclude = list(exclude_headers or []) + ["Authorization"]
            headers = self._header_manager.get_headers(
                extra=extra_headers,
                exclude=exclude,
            )

        req: dict = {
            "method":  method,
            "url":     url,
            "headers": headers,
        }

        if body is not None:
            req["json"] = body

        if params:
            req["params"] = params

        logger.info(
            "Request built | %s %s | body=%s | params=%s",
            method,
            url,
            "yes" if body else "none",
            params or "none",
        )
        return req

    # ── private ────────────────────────────────────────────────────────────

    @staticmethod
    def _build_url(endpoint: str) -> str:
        """Safely join base_url + endpoint, handling leading slashes."""
        base = config.base_url.rstrip("/")
        ep   = endpoint.lstrip("/")
        return f"{base}/{ep}"
