"""
keywords/ApiKeywords.py
────────────────────────
The single Python-to-Robot bridge.
Every Robot keyword in this framework calls a method here.

Design rules:
  • Methods are thin wrappers — real logic lives in core/ and utilities/.
  • Method names map 1-to-1 to Robot keyword names (Robot converts snake_case → Title Case With Spaces).
  • All Robot-facing values are plain Python types (str, int, dict, list).
  • Logging is done inside core/utilities layers; keywords log only at entry.

Auto-initialised at import:
  • Logging (from config YAML)
  • APIClient (which wires TokenManager → HeaderManager → RequestManager)
"""

import logging
from robot.api.deco import keyword, library

from utilities.logger import setup_logging, get_logger
from config.config_loader import config
from core.api_client import APIClient, APIResponse
from core.payload_builder import PayloadBuilder
from utilities.faker_utils import FakerUtils
from utilities.json_utils import load_json, save_json, extract, diff, flatten
from utilities.schema_validator import SchemaValidator
from utilities.response_validator import ResponseValidator

# Initialise logging the moment Robot imports this library
setup_logging()
logger = get_logger(__name__)


@library(scope="SUITE")   # one instance per suite → shared token cache across tests
class ApiKeywords:
    """Robot Framework keyword library for API testing."""

    ROBOT_LIBRARY_DOC_FORMAT = "reST"

    def __init__(self):
        logger.info("ApiKeywords init | env=%s | base_url=%s", config.env, config.base_url)
        self._client    = APIClient()
        self._faker     = FakerUtils()
        self._schema_v  = SchemaValidator()
        self._resp_v    = ResponseValidator()

    # ══════════════════════════════════════════════════════════════════════
    # REQUEST KEYWORDS
    # ══════════════════════════════════════════════════════════════════════

    @keyword("Send GET Request")
    def send_get_request(
        self,
        endpoint: str,
        params: dict | None = None,
        extra_headers: dict | None = None,
    ) -> APIResponse:
        """Send a GET request and return the APIResponse object."""
        logger.info("KW | Send GET Request | endpoint=%s", endpoint)
        return self._client.send("GET", endpoint, params=params, extra_headers=extra_headers)

    @keyword("Send POST Request")
    def send_post_request(
        self,
        endpoint: str,
        body: dict,
        extra_headers: dict | None = None,
    ) -> APIResponse:
        """Send a POST request with `body` and return the APIResponse object."""
        logger.info("KW | Send POST Request | endpoint=%s", endpoint)
        return self._client.send("POST", endpoint, body=body, extra_headers=extra_headers)

    @keyword("Send PUT Request")
    def send_put_request(
        self,
        endpoint: str,
        body: dict,
        extra_headers: dict | None = None,
    ) -> APIResponse:
        logger.info("KW | Send PUT Request | endpoint=%s", endpoint)
        return self._client.send("PUT", endpoint, body=body, extra_headers=extra_headers)

    @keyword("Send PATCH Request")
    def send_patch_request(
        self,
        endpoint: str,
        body: dict,
        extra_headers: dict | None = None,
    ) -> APIResponse:
        logger.info("KW | Send PATCH Request | endpoint=%s", endpoint)
        return self._client.send("PATCH", endpoint, body=body, extra_headers=extra_headers)

    @keyword("Send DELETE Request")
    def send_delete_request(
        self,
        endpoint: str,
        extra_headers: dict | None = None,
    ) -> APIResponse:
        logger.info("KW | Send DELETE Request | endpoint=%s", endpoint)
        return self._client.send("DELETE", endpoint, extra_headers=extra_headers)

    @keyword("Send Unauthenticated GET Request")
    def send_unauthenticated_get_request(self, endpoint: str) -> APIResponse:
        """Send a GET without the Authorization header — for testing 401 scenarios."""
        logger.info("KW | Send Unauthenticated GET Request | endpoint=%s", endpoint)
        return self._client.send("GET", endpoint, auth=False)

    # ══════════════════════════════════════════════════════════════════════
    # DYNAMIC WAIT KEYWORD
    # ══════════════════════════════════════════════════════════════════════

    @keyword("Wait Until Status Code Is")
    def wait_until_status_code_is(
        self,
        endpoint: str,
        expected_status: int,
        timeout: int = 60,
        interval: int = 3,
        method: str = "GET",
        body: dict | None = None,
    ) -> APIResponse:
        """
        Poll `endpoint` every `interval` seconds until the response
        status code equals `expected_status`, or `timeout` seconds elapse.
        """
        expected_status = int(expected_status)
        logger.info(
            "KW | Wait Until Status Code Is | %s %s → expected=%d timeout=%ds",
            method, endpoint, expected_status, timeout,
        )
        return self._client.wait_until(
            method    = method,
            endpoint  = endpoint,
            condition = lambda r: r.status_code == expected_status,
            timeout   = int(timeout),
            interval  = int(interval),
            body      = body,
        )

    @keyword("Wait Until Field Value Is")
    def wait_until_field_value_is(
        self,
        endpoint: str,
        field_path: str,
        expected_value: str,
        timeout: int = 60,
        interval: int = 3,
    ) -> APIResponse:
        """
        Poll until response_body[field_path] == expected_value.
        field_path uses dot notation, e.g. "data.status"
        """
        logger.info(
            "KW | Wait Until Field Value Is | endpoint=%s field=%s value=%s",
            endpoint, field_path, expected_value,
        )
        keys = field_path.split(".")

        def condition(r: APIResponse) -> bool:
            try:
                body = r.json()
            except Exception:
                return False
            return extract(body, *keys) == expected_value

        return self._client.wait_until(
            method   = "GET",
            endpoint = endpoint,
            condition = condition,
            timeout  = int(timeout),
            interval = int(interval),
        )

    # ══════════════════════════════════════════════════════════════════════
    # VALIDATION KEYWORDS
    # ══════════════════════════════════════════════════════════════════════

    @keyword("Response Status Should Be")
    def response_status_should_be(self, response: APIResponse, expected_status: int) -> None:
        self._resp_v.assert_status(response, int(expected_status))

    @keyword("Response Should Be Successful")
    def response_should_be_successful(self, response: APIResponse) -> None:
        self._resp_v.assert_success(response)

    @keyword("Response Field Should Equal")
    def response_field_should_equal(
        self, response: APIResponse, field_path: str, expected
    ) -> None:
        self._resp_v.assert_field_equals(response, field_path, expected)

    @keyword("Response Field Should Exist")
    def response_field_should_exist(self, response: APIResponse, field_path: str) -> None:
        self._resp_v.assert_field_exists(response, field_path)

    @keyword("Response Field Should Not Be Empty")
    def response_field_should_not_be_empty(
        self, response: APIResponse, field_path: str
    ) -> None:
        self._resp_v.assert_field_not_empty(response, field_path)

    @keyword("Response List Should Not Be Empty")
    def response_list_should_not_be_empty(
        self, response: APIResponse, field_path: str
    ) -> None:
        self._resp_v.assert_list_not_empty(response, field_path)

    @keyword("Response Time Should Be Under")
    def response_time_should_be_under(self, response: APIResponse, max_ms: float) -> None:
        self._resp_v.assert_response_time(response, float(max_ms))

    @keyword("Validate Response Schema")
    def validate_response_schema(self, response: APIResponse, schema_name: str) -> None:
        """Validate the response body against testdata/schemas/<schema_name>.json"""
        body = response.json()
        self._schema_v.validate(body, schema_name)

    # ══════════════════════════════════════════════════════════════════════
    # PAYLOAD BUILDER KEYWORDS
    # ══════════════════════════════════════════════════════════════════════

    @keyword("Build Payload From File")
    def build_payload_from_file(self, file_path: str, overrides: dict | None = None) -> dict:
        """
        Load a JSON payload file and optionally override specific keys.
        Returns a plain dict.
        """
        builder = PayloadBuilder.from_file(file_path)
        if overrides:
            builder.merge(overrides)
        return builder.build()

    @keyword("Build Payload")
    def build_payload(self, **kwargs) -> dict:
        """Build a payload from keyword arguments. Usage: Build Payload  name=Alice  role=admin"""
        builder = PayloadBuilder()
        for key, val in kwargs.items():
            builder.set(key, val)
        return builder.build()

    # ══════════════════════════════════════════════════════════════════════
    # FAKE DATA KEYWORDS
    # ══════════════════════════════════════════════════════════════════════

    @keyword("Generate Random User Payload")
    def generate_random_user_payload(self, role: str = "user") -> dict:
        return self._faker.random_user_payload(role=role)

    @keyword("Generate Random Email")
    def generate_random_email(self) -> str:
        return self._faker.random_email()

    @keyword("Generate Random UUID")
    def generate_random_uuid(self) -> str:
        return self._faker.random_uuid()

    @keyword("Generate Random Name")
    def generate_random_name(self) -> str:
        return self._faker.random_name()

    # ══════════════════════════════════════════════════════════════════════
    # JSON UTILITY KEYWORDS
    # ══════════════════════════════════════════════════════════════════════

    @keyword("Get JSON Field")
    def get_json_field(self, data: dict, *keys: str):
        """Extract a (possibly nested) value using dot-separated key path."""
        return extract(data, *keys)

    @keyword("Load JSON File")
    def load_json_file(self, path: str) -> dict:
        return load_json(path)

    @keyword("Get Response Body")
    def get_response_body(self, response: APIResponse) -> dict | list:
        return response.json()

    @keyword("Get Response Status Code")
    def get_response_status_code(self, response: APIResponse) -> int:
        return response.status_code

    # ══════════════════════════════════════════════════════════════════════
    # CONFIG / ENV KEYWORDS
    # ══════════════════════════════════════════════════════════════════════

    @keyword("Get Current Environment")
    def get_current_environment(self) -> str:
        """Returns the active environment name (dev / qa / prod)."""
        return config.env

    @keyword("Get Base URL")
    def get_base_url(self) -> str:
        return config.base_url

    @keyword("Log Framework Config")
    def log_framework_config(self) -> None:
        """Log full config details at INFO level — useful in Suite Setup."""
        logger.info(
            "Framework config | env=%s | base_url=%s | timeout=%ds | retries=%d | log_level=%s",
            config.env, config.base_url, config.timeout, config.retries, config.log_level,
        )
