"""
config_loader.py
────────────────
Single source of truth for environment configuration.

Priority order (highest → lowest):
  1. ENV variable  : FRAMEWORK_ENV=prod  (set in CI/CD or shell)
  2. Default       : qa

Usage (Python):
    from config.config_loader import config
    print(config.base_url)
    print(config.timeout)

Usage (Robot via ApiKeywords):
    Automatically loaded — tests never touch this directly.
"""

import os
import re
import yaml
from pathlib import Path

# ── locate config directory relative to THIS file ──────────────────────────
_CONFIG_DIR = Path(__file__).parent
_VALID_ENVS = {"dev", "qa", "prod"}
_DEFAULT_ENV = "qa"


def _resolve_env_vars(value: str) -> str:
    """Replace ${VAR_NAME} placeholders with actual OS env vars."""
    pattern = re.compile(r"\$\{([^}]+)\}")
    def replacer(m):
        var = m.group(1)
        resolved = os.environ.get(var, "")
        if not resolved:
            import warnings
            warnings.warn(f"[config] env var '{var}' is not set — using empty string")
        return resolved
    return pattern.sub(replacer, value)


def _resolve_dict(d: dict) -> dict:
    """Recursively resolve env-var placeholders in all string values."""
    result = {}
    for k, v in d.items():
        if isinstance(v, dict):
            result[k] = _resolve_dict(v)
        elif isinstance(v, str):
            result[k] = _resolve_env_vars(v)
        else:
            result[k] = v
    return result


class Config:
    """
    Typed, attribute-style access to YAML config values.
    Change ENV in one place (env var or default above) and every
    import of `config` throughout the entire framework picks it up.
    """

    def __init__(self, env: str):
        yaml_path = _CONFIG_DIR / f"{env}.yaml"
        if not yaml_path.exists():
            raise FileNotFoundError(
                f"[config] No config file found for env='{env}' at {yaml_path}"
            )

        with open(yaml_path, "r") as fh:
            raw = yaml.safe_load(fh)

        data = _resolve_dict(raw)

        # ── top-level shortcuts ────────────────────────────────────────────
        self.env: str            = data["env"]
        self.base_url: str       = data["base_url"]

        # auth block
        _auth                    = data["auth"]
        self.token_url: str      = self.base_url + _auth["token_url"]
        self.client_id: str      = _auth["client_id"]
        self.client_secret: str  = _auth["client_secret"]
        self.grant_type: str     = _auth["grant_type"]

        # logging block
        _log                     = data["logging"]
        self.log_level: str      = _log["level"]
        self.log_file: str       = _log["log_file"]

        # http block
        _http                    = data["http"]
        self.timeout: int        = int(_http["timeout"])
        self.retries: int        = int(_http["retries"])
        self.retry_delay: int    = int(_http["retry_delay"])

        # test run block
        self.suites: list        = data["test_run"]["suites"]

        # keep raw dict available for any edge case
        self._raw = data

    def __repr__(self) -> str:
        return (
            f"<Config env={self.env} base_url={self.base_url} "
            f"timeout={self.timeout}s retries={self.retries}>"
        )


# ── module-level singleton ─────────────────────────────────────────────────
# Every `from config.config_loader import config` gets the SAME object.
def _load() -> Config:
    raw_env = os.environ.get("FRAMEWORK_ENV", _DEFAULT_ENV).strip().lower()
    if raw_env not in _VALID_ENVS:
        raise ValueError(
            f"[config] FRAMEWORK_ENV='{raw_env}' is invalid. "
            f"Choose from: {_VALID_ENVS}"
        )
    return Config(raw_env)


config: Config = _load()
