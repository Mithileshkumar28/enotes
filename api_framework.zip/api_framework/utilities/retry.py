"""
utilities/retry.py
───────────────────
Two ways to add retry logic:

  1. @retry decorator   — decorate a function; retries on any Exception.
  2. retry_call()       — wrap a callable inline without modifying it.

Retry count and delay come from config (change one YAML → affects all).

Uses `tenacity` under the hood (listed in requirements.txt).

Usage:
    # Decorator
    @retry
    def flaky_operation():
        ...

    # Inline
    result = retry_call(lambda: client.send("GET", "/health"))
"""

import logging
from typing import Callable, Any, Type

from tenacity import (
    retry,
    stop_after_attempt,
    wait_fixed,
    retry_if_exception_type,
    before_sleep_log,
    RetryError,
)

from config.config_loader import config
from utilities.logger import get_logger

logger = get_logger(__name__)


def _build_retry(**overrides):
    """
    Internal factory — reads retries/retry_delay from config, allows overrides.
    """
    max_attempts   = overrides.get("retries",     config.retries) + 1   # attempts = retries + 1
    wait_seconds   = overrides.get("retry_delay", config.retry_delay)
    exc_types      = overrides.get("exc_types",   (Exception,))

    return retry(
        stop            = stop_after_attempt(max_attempts),
        wait            = wait_fixed(wait_seconds),
        retry           = retry_if_exception_type(exc_types),
        before_sleep    = before_sleep_log(logger, logging.WARNING),
        reraise         = True,
    )


# ── decorator ──────────────────────────────────────────────────────────────

def with_retry(
    retries: int | None = None,
    retry_delay: int | None = None,
    exc_types: tuple[Type[Exception], ...] = (Exception,),
):
    """
    Parameterised decorator factory.

    @with_retry()                        # uses config values
    @with_retry(retries=5, retry_delay=2)
    def my_fn(): ...
    """
    kwargs = {}
    if retries    is not None: kwargs["retries"]     = retries
    if retry_delay is not None: kwargs["retry_delay"] = retry_delay
    kwargs["exc_types"] = exc_types
    return _build_retry(**kwargs)


# ── inline helper ──────────────────────────────────────────────────────────

def retry_call(
    fn: Callable,
    *args,
    retries: int | None = None,
    retry_delay: int | None = None,
    exc_types: tuple[Type[Exception], ...] = (Exception,),
    **kwargs,
) -> Any:
    """
    Call fn(*args, **kwargs) with retry logic without decorating it.

    Example:
        response = retry_call(client.send, "GET", "/health")
        response = retry_call(client.send, "POST", "/users",
                              body=payload, retries=5)
    """
    decorated = _build_retry(
        **{k: v for k, v in
           {"retries": retries, "retry_delay": retry_delay, "exc_types": exc_types}.items()
           if v is not None}
    )(fn)
    return decorated(*args, **kwargs)


__all__ = ["with_retry", "retry_call", "RetryError"]
