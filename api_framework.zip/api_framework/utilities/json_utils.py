"""
utilities/json_utils.py
────────────────────────
Utility helpers for JSON — loading, saving, extracting nested values,
diffing two dicts, and flattening nested structures.

Kept small: only methods genuinely needed by Robot keywords.
"""

import json
from pathlib import Path
from typing import Any

from utilities.logger import get_logger

logger = get_logger(__name__)


def load_json(path: str) -> dict | list:
    """Load a JSON file and return a Python dict/list."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"[json_utils] File not found: {path}")
    with open(p, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    logger.debug("Loaded JSON from %s", path)
    return data


def save_json(data: dict | list, path: str, indent: int = 2) -> None:
    """Serialize data to a JSON file (creates parent dirs if needed)."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=indent, ensure_ascii=False)
    logger.debug("Saved JSON to %s", path)


def extract(data: dict, *keys: str, default=None) -> Any:
    """
    Safely extract a nested value using a key path.

    extract(resp_body, "data", "user", "id")
    → resp_body["data"]["user"]["id"]  or  default if any key is missing
    """
    current = data
    for key in keys:
        if not isinstance(current, dict):
            logger.debug("extract: key '%s' not reachable — returning default", key)
            return default
        current = current.get(key, default)
        if current is default:
            return default
    return current


def diff(expected: dict, actual: dict) -> dict:
    """
    Return a dict of keys where expected != actual.
    Only compares top-level keys present in `expected`.

    Returns {} if no differences found.
    """
    differences = {}
    for key, exp_val in expected.items():
        act_val = actual.get(key)
        if act_val != exp_val:
            differences[key] = {"expected": exp_val, "actual": act_val}
    if differences:
        logger.warning("JSON diff found %d difference(s): %s", len(differences), differences)
    return differences


def flatten(data: dict, separator: str = ".", prefix: str = "") -> dict:
    """
    Flatten a nested dict into a single-level dict.

    flatten({"a": {"b": 1, "c": 2}}) → {"a.b": 1, "a.c": 2}
    """
    result = {}
    for key, value in data.items():
        full_key = f"{prefix}{separator}{key}" if prefix else key
        if isinstance(value, dict):
            result.update(flatten(value, separator=separator, prefix=full_key))
        else:
            result[full_key] = value
    return result
