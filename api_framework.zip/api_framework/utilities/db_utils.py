"""
utilities/db_utils.py
──────────────────────
PostgreSQL database helper using SQLAlchemy + psycopg2.

NOTE: This class is DEFINED but NOT USED in any Robot keywords by default.
It is here so the DB layer is ready whenever a test needs direct DB validation.
No DB calls fire unless you explicitly instantiate DBUtils and call its methods.

To activate: set DB_* env vars and call DBUtils() in a keyword.

Required env vars:
    DB_HOST     DB_PORT (default 5432)
    DB_NAME     DB_USER     DB_PASSWORD
"""

import os
import logging

from utilities.logger import get_logger

logger = get_logger(__name__)


class DBUtils:
    """
    Lightweight wrapper around SQLAlchemy for test-time DB assertions.

    Usage:
        db = DBUtils()
        row = db.fetch_one("SELECT * FROM users WHERE email = %s", params=("alice@example.com",))
        db.assert_row_exists("SELECT id FROM users WHERE id = %s", params=(user_id,))
        db.close()
    """

    def __init__(self):
        # Import here so missing psycopg2 only fails when DBUtils is actually used
        try:
            from sqlalchemy import create_engine, text
            self._text = text
        except ImportError:
            raise ImportError(
                "SQLAlchemy is not installed. Run: pip install sqlalchemy psycopg2-binary"
            )

        host     = os.environ.get("DB_HOST", "localhost")
        port     = os.environ.get("DB_PORT", "5432")
        name     = os.environ.get("DB_NAME", "testdb")
        user     = os.environ.get("DB_USER", "postgres")
        password = os.environ.get("DB_PASSWORD", "")

        dsn = f"postgresql+psycopg2://{user}:{password}@{host}:{port}/{name}"
        logger.info("DBUtils connecting to %s:%s/%s", host, port, name)

        from sqlalchemy import create_engine
        self._engine = create_engine(dsn, pool_pre_ping=True)

    # ── public ─────────────────────────────────────────────────────────────

    def fetch_one(self, sql: str, params: tuple = ()) -> dict | None:
        """Execute `sql` and return the first row as a dict, or None."""
        logger.debug("DB fetch_one | sql=%s | params=%s", sql.strip(), params)
        with self._engine.connect() as conn:
            result = conn.execute(self._text(sql), params)
            row = result.mappings().first()
            return dict(row) if row else None

    def fetch_all(self, sql: str, params: tuple = ()) -> list[dict]:
        """Execute `sql` and return all rows as a list of dicts."""
        logger.debug("DB fetch_all | sql=%s | params=%s", sql.strip(), params)
        with self._engine.connect() as conn:
            result = conn.execute(self._text(sql), params)
            return [dict(r) for r in result.mappings().all()]

    def execute(self, sql: str, params: tuple = ()) -> None:
        """Execute a non-SELECT statement (INSERT / UPDATE / DELETE)."""
        logger.info("DB execute | sql=%s | params=%s", sql.strip(), params)
        with self._engine.begin() as conn:
            conn.execute(self._text(sql), params)

    def assert_row_exists(self, sql: str, params: tuple = ()) -> dict:
        """Assert at least one row is returned; raises AssertionError if not."""
        row = self.fetch_one(sql, params)
        assert row is not None, f"DB assertion failed — no row found for: {sql!r} params={params}"
        logger.info("DB assert_row_exists PASSED ✓")
        return row

    def assert_row_not_exists(self, sql: str, params: tuple = ()) -> None:
        """Assert no row matches the query."""
        row = self.fetch_one(sql, params)
        assert row is None, f"DB assertion failed — unexpected row found: {row}"
        logger.info("DB assert_row_not_exists PASSED ✓")

    def close(self) -> None:
        self._engine.dispose()
        logger.info("DBUtils connection disposed")
