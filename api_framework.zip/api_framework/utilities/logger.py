"""
utilities/logger.py
────────────────────
Central logging setup.  Call setup_logging() once at framework boot
(done automatically in ApiKeywords.py).

After that, every module just does:
    import logging
    logger = logging.getLogger(__name__)

Log level and file destination are driven by config/  ← change once, works everywhere.
"""

import logging
import sys
from pathlib import Path

from config.config_loader import config

# Track whether we've already configured root logger to avoid duplicate handlers
_configured = False


def setup_logging() -> logging.Logger:
    """
    Configure the root logger from config YAML.
    Returns the root logger so callers can use it immediately.

    Log format:
      2024-01-15 12:34:56,789 | INFO     | core.api_client      | GET /users → 200 OK
    """
    global _configured
    if _configured:
        return logging.getLogger()

    numeric_level = getattr(logging, config.log_level.upper(), logging.INFO)

    fmt = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)-25s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root = logging.getLogger()
    root.setLevel(numeric_level)

    # ── console handler ────────────────────────────────────────────────────
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(numeric_level)
    console.setFormatter(fmt)
    root.addHandler(console)

    # ── file handler ───────────────────────────────────────────────────────
    log_path = Path(config.log_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    file_handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")
    file_handler.setLevel(numeric_level)
    file_handler.setFormatter(fmt)
    root.addHandler(file_handler)

    _configured = True

    root.info(
        "Logging initialised | env=%s | level=%s | file=%s",
        config.env,
        config.log_level,
        config.log_file,
    )
    return root


def get_logger(name: str) -> logging.Logger:
    """Convenience wrapper — ensures root is configured before returning a named logger."""
    setup_logging()
    return logging.getLogger(name)
