"""
utilities/response_validator.py
────────────────────────────────
Pre-built validation bundles so Robot keywords read like English
instead of asserting individual fields one at a time.

Usage:
    from utilities.response_validator import ResponseValidator
    rv = ResponseValidator()
    rv.assert_status(response, 200)
    rv.assert_success(response)
    rv.assert_field_equals(response, "data.user.email", "alice@example.com")
    rv.assert_list_not_empty(response, "data.items")
"""

from typing import Any

from utilities.logger import get_logger
from utilities.json_utils import extract

logger = get_logger(__name__)


class ResponseValidator:

    # ── status ─────────────────────────────────────────────────────────────

    def assert_status(self, response, expected_status: int) -> None:
        actual = response.status_code
        logger.info("Assert status | expected=%d actual=%d", expected_status, actual)
        assert actual == expected_status, (
            f"Expected status {expected_status}, got {actual}.\n"
            f"URL: {response.url}\nBody: {response.body}"
        )

    def assert_status_in(self, response, *expected_statuses: int) -> None:
        actual = response.status_code
        assert actual in expected_statuses, (
            f"Expected status in {expected_statuses}, got {actual}.\nBody: {response.body}"
        )

    def assert_success(self, response) -> None:
        """2xx range check."""
        assert response.ok, (
            f"Expected 2xx, got {response.status_code}.\nBody: {response.body}"
        )

    # ── body field assertions ───────────────────────────────────────────────

    def assert_field_equals(self, response, field_path: str, expected: Any) -> None:
        """
        Assert a (possibly nested) field equals expected.
        field_path uses dot notation: "data.user.email"
        """
        keys = field_path.split(".")
        body = response.json() if callable(response.json) else response.body
        actual = extract(body, *keys)
        logger.info("Assert field '%s' == '%s' (actual='%s')", field_path, expected, actual)
        assert actual == expected, (
            f"Field '{field_path}': expected '{expected}', got '{actual}'."
        )

    def assert_field_exists(self, response, field_path: str) -> None:
        """Assert the field is present (not None) in the response body."""
        _MISSING = object()
        keys = field_path.split(".")
        body = response.json() if callable(response.json) else response.body
        actual = extract(body, *keys, default=_MISSING)
        logger.info("Assert field exists: '%s' → %s", field_path, actual is not _MISSING)
        assert actual is not _MISSING, (
            f"Field '{field_path}' is missing from response body."
        )

    def assert_field_not_empty(self, response, field_path: str) -> None:
        """Assert the field is present AND not falsy (not None/empty string/empty list)."""
        keys = field_path.split(".")
        body = response.json() if callable(response.json) else response.body
        actual = extract(body, *keys)
        assert actual, f"Field '{field_path}' is empty or missing. Got: {actual!r}"

    def assert_list_not_empty(self, response, field_path: str) -> None:
        """Assert the field is a non-empty list."""
        keys = field_path.split(".")
        body = response.json() if callable(response.json) else response.body
        actual = extract(body, *keys)
        assert isinstance(actual, list) and len(actual) > 0, (
            f"Field '{field_path}' is not a non-empty list. Got: {actual!r}"
        )

    def assert_response_time(self, response, max_ms: float) -> None:
        """Assert response arrived within max_ms milliseconds."""
        actual = response.elapsed_ms
        logger.info("Assert response time | %.0fms <= %.0fms", actual, max_ms)
        assert actual <= max_ms, (
            f"Response took {actual:.0f}ms, expected ≤ {max_ms:.0f}ms."
        )

    def assert_header_equals(self, response, header_name: str, expected: str) -> None:
        actual = response.headers.get(header_name)
        logger.info("Assert header '%s' == '%s' (actual='%s')", header_name, expected, actual)
        assert actual == expected, (
            f"Header '{header_name}': expected '{expected}', got '{actual}'."
        )
