"""
utilities/schema_validator.py
──────────────────────────────
Validates a dict/list response body against a JSON Schema file
stored in testdata/schemas/.

Usage:
    from utilities.schema_validator import SchemaValidator
    sv = SchemaValidator()
    sv.validate(response_body, "user")        # loads testdata/schemas/user.json
    sv.validate(response_body, "user.json")   # same — extension optional
"""

import json
from pathlib import Path

import jsonschema
from jsonschema import ValidationError, SchemaError

from utilities.logger import get_logger

logger = get_logger(__name__)

_SCHEMA_DIR = Path(__file__).parent.parent / "testdata" / "schemas"


class SchemaValidator:

    def validate(self, data: dict | list, schema_name: str) -> None:
        """
        Validate `data` against `schema_name`.

        Args:
            data        : The parsed response body to validate.
            schema_name : Schema filename (with or without .json extension).

        Raises:
            jsonschema.ValidationError  on schema mismatch.
            FileNotFoundError           if schema file doesn't exist.
        """
        schema_path = self._resolve_path(schema_name)
        schema = self._load_schema(schema_path)

        logger.info("Validating response against schema: %s", schema_path.name)
        try:
            jsonschema.validate(instance=data, schema=schema)
            logger.info("Schema validation PASSED ✓ (%s)", schema_path.name)
        except ValidationError as exc:
            logger.error(
                "Schema validation FAILED ✗ | schema=%s | path=%s | message=%s",
                schema_path.name,
                " → ".join(str(p) for p in exc.absolute_path),
                exc.message,
            )
            raise

    # ── private ────────────────────────────────────────────────────────────

    @staticmethod
    def _resolve_path(schema_name: str) -> Path:
        name = schema_name if schema_name.endswith(".json") else f"{schema_name}.json"
        path = _SCHEMA_DIR / name
        if not path.exists():
            raise FileNotFoundError(
                f"[SchemaValidator] Schema not found: {path}\n"
                f"Available schemas: {list(_SCHEMA_DIR.glob('*.json'))}"
            )
        return path

    @staticmethod
    def _load_schema(path: Path) -> dict:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
