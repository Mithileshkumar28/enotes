*** Settings ***
Documentation     Regression tests — full CRUD coverage for the User resource.
...               Runs in dev and qa environments.
Library           ../../keywords/ApiKeywords.py
Resource          ../../resources/auth_keywords.robot
Resource          ../../resources/common_keywords.robot
Resource          ../../resources/user_keywords.robot
Library           Collections

Suite Setup       Setup API Session
Test Tags         regression

*** Variables ***
${UPDATED_ROLE}    admin

*** Test Cases ***

TC_R001 — Get All Users Returns Non-Empty List
    ${response}=    Get All Users And Verify
    Assert List Is Not Empty    ${response}    data

TC_R002 — Create User With Valid Payload Returns 201
    ${payload}=     Generate Random User Payload
    ${response}=    Create User    ${payload}
    Assert Status 201    ${response}
    Assert Schema    ${response}    user

TC_R003 — Create User Response Contains ID
    ${payload}=     Generate Random User Payload
    ${response}=    Create User And Verify    ${payload}
    Assert Field Exists    ${response}    data.id

TC_R004 — Create User Stores Correct Email
    ${payload}=     Generate Random User Payload
    ${email}=       Get From Dictionary    ${payload}    email
    ${response}=    Create User And Verify    ${payload}
    Assert Field Value    ${response}    data.email    ${email}

TC_R005 — Get User By ID Returns Correct User
    ${create}=      Create Random User
    ${user_id}=     Extract User ID From Response    ${create}
    ${response}=    Get User And Verify    ${user_id}
    Assert Field Value    ${response}    data.id    ${user_id}

TC_R006 — Get Non-Existent User Returns 404
    ${response}=    Get User By ID    non-existent-id-000
    Assert Status 404    ${response}

TC_R007 — Update User Returns 200 With Updated Data
    ${create}=        Create Random User
    ${user_id}=       Extract User ID From Response    ${create}
    ${payload}=       Generate Random User Payload    role=${UPDATED_ROLE}
    ${response}=      Update User And Verify    ${user_id}    ${payload}
    Assert Field Value    ${response}    data.role    ${UPDATED_ROLE}

TC_R008 — Patch User Email Updates Successfully
    ${create}=      Create Random User
    ${user_id}=     Extract User ID From Response    ${create}
    ${new_email}=   Generate Random Email
    ${patch}=       Build Payload    email=${new_email}
    ${response}=    Patch User    ${user_id}    ${patch}
    Assert Status 200    ${response}
    Assert Field Value    ${response}    data.email    ${new_email}

TC_R009 — Delete User Returns 200
    ${create}=      Create Random User
    ${user_id}=     Extract User ID From Response    ${create}
    ${response}=    Delete User And Verify    ${user_id}

TC_R010 — Deleted User Returns 404 On Fetch
    ${create}=      Create Random User
    ${user_id}=     Extract User ID From Response    ${create}
    Delete User And Verify    ${user_id}
    ${response}=    Get User By ID    ${user_id}
    Assert Status 404    ${response}

TC_R011 — Create User With Missing Required Field Returns 400
    ${payload}=    Build Payload    role=user
    ${response}=   Create User    ${payload}
    Assert Status 400    ${response}

TC_R012 — Create User With Invalid Email Returns 422
    ${payload}=    Build Payload    email=not-an-email    role=user    first_name=Test    last_name=User
    ${response}=   Create User    ${payload}
    Assert Status 422    ${response}

TC_R013 — Response Schema Is Valid For User Create
    ${payload}=     Generate Random User Payload
    ${response}=    Create User And Verify    ${payload}
    Assert Schema    ${response}    user

TC_R014 — Response Time Is Within Acceptable Limit
    ${response}=    Send GET Request    /users
    Assert Response Time Under    ${response}    3000

TC_R015 — Get Users Supports Query Params
    ${params}=      Create Dictionary    page=1    limit=5
    ${response}=    Get All Users    params=${params}
    Assert Status 200    ${response}
    Assert List Is Not Empty    ${response}    data
