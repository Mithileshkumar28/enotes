*** Settings ***
Documentation     Integration tests — end-to-end flows spanning multiple API calls.
...               Tests full user lifecycle and cross-resource interactions.
Library           ../../keywords/ApiKeywords.py
Resource          ../../resources/auth_keywords.robot
Resource          ../../resources/common_keywords.robot
Resource          ../../resources/user_keywords.robot
Library           Collections

Suite Setup       Setup API Session
Test Tags         integration

*** Test Cases ***

TC_I001 — Full User Lifecycle: Create → Read → Update → Delete
    [Documentation]    Verifies a complete user lifecycle in one flow.
    # Create
    ${payload}=       Generate Random User Payload
    ${create_resp}=   Create User And Verify    ${payload}
    ${user_id}=       Extract User ID From Response    ${create_resp}
    Log    Created user with ID: ${user_id}    console=yes

    # Read
    ${get_resp}=      Get User And Verify    ${user_id}
    Assert Field Value    ${get_resp}    data.id    ${user_id}

    # Update
    ${update_payload}=    Generate Random User Payload    role=admin
    ${upd_resp}=      Update User And Verify    ${user_id}    ${update_payload}
    Assert Field Value    ${upd_resp}    data.role    admin

    # Delete
    Delete User And Verify    ${user_id}

    # Confirm deletion
    ${gone}=    Get User By ID    ${user_id}
    Assert Status 404    ${gone}

TC_I002 — Create Multiple Users And Verify List Grows
    [Documentation]    Create 3 users and verify the list count increases.
    Create Random User
    Create Random User
    Create Random User
    ${response}=    Get All Users And Verify
    Assert List Is Not Empty    ${response}    data

TC_I003 — Wait Until Async User Status Is Active
    [Documentation]    Demonstrates dynamic wait for async processing.
    ...                In a real system this would poll a job/status endpoint.
    ${payload}=     Generate Random User Payload
    ${create}=      Create User And Verify    ${payload}
    ${user_id}=     Extract User ID From Response    ${create}
    # Dynamic wait: poll until user status field equals "active"
    ${response}=    Wait For Field Value
    ...             endpoint=/users/${user_id}
    ...             field_path=data.status
    ...             expected_value=active
    ...             timeout=30
    ...             interval=3
    Assert Status 200    ${response}

TC_I004 — Load Payload From File And Override Field
    [Documentation]    Use PayloadBuilder.from_file() via keyword.
    ${email}=       Generate Random Email
    ${payload}=     Build Payload From File
    ...             testdata/payloads/create_user.json
    ...             overrides={"email": "${email}"}
    ${response}=    Create User    ${payload}
    Assert Status 201    ${response}

TC_I005 — Concurrent Role Changes Do Not Corrupt User
    [Documentation]    PATCH email, then PATCH role separately; verify both are persisted.
    ${create}=      Create Random User
    ${user_id}=     Extract User ID From Response    ${create}

    ${new_email}=   Generate Random Email
    ${patch_email}= Build Payload    email=${new_email}
    ${r1}=          Patch User    ${user_id}    ${patch_email}
    Assert Status 200    ${r1}

    ${patch_role}=  Build Payload    role=editor
    ${r2}=          Patch User    ${user_id}    ${patch_role}
    Assert Status 200    ${r2}

    ${final}=       Get User And Verify    ${user_id}
    Assert Field Value    ${final}    data.email    ${new_email}
    Assert Field Value    ${final}    data.role     editor
