*** Settings ***
Documentation     Smoke tests — quick confidence checks that core API routes are alive.
...               Runs in ALL environments (dev / qa / prod).
Library           ../../keywords/ApiKeywords.py
Resource          ../../resources/auth_keywords.robot
Resource          ../../resources/common_keywords.robot
Resource          ../../resources/user_keywords.robot

Suite Setup       Setup API Session
Test Tags         smoke

*** Test Cases ***

TC_S001 — API Health Check
    [Documentation]    Verify the API is reachable and returns 200.
    ${response}=    Send GET Request    /health
    Assert Status 200    ${response}

TC_S002 — Get All Users Returns 200
    [Documentation]    Verify the users list endpoint responds successfully.
    ${response}=    Get All Users
    Assert Status 200    ${response}

TC_S003 — Create User Returns 201
    [Documentation]    POST a new user with random data, expect 201.
    ${payload}=     Generate Random User Payload
    ${response}=    Create User    ${payload}
    Assert Status 201    ${response}

TC_S004 — Get User By ID Returns 200
    [Documentation]    Create a user, then fetch by ID.
    ${response}=    Create Random User
    ${user_id}=     Extract User ID From Response    ${response}
    ${get_resp}=    Get User And Verify    ${user_id}
    Assert Field Value    ${get_resp}    data.id    ${user_id}

TC_S005 — Unauthenticated Request Returns 401
    [Documentation]    Verify that missing Authorization header yields 401.
    ${response}=    Send Unauthenticated GET Request    /users
    Assert Status 401    ${response}
