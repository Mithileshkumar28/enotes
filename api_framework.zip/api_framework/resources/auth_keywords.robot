*** Settings ***
Documentation     Authentication-level keywords: session setup, token refresh.
Library           ../keywords/ApiKeywords.py
Library           Collections

*** Keywords ***

Setup API Session
    [Documentation]    Must be called in Suite Setup.
    ...                Logs the active env and verifies the API is reachable.
    Log Framework Config
    ${env}=    Get Current Environment
    Log    Running against environment: ${env}    console=yes

Verify API Is Reachable
    [Documentation]    Simple health-check; fails the suite early if API is down.
    [Arguments]    ${health_endpoint}=/health
    ${response}=    Send GET Request    ${health_endpoint}
    Response Status Should Be    ${response}    200

Refresh Auth Token
    [Documentation]    Force a new token fetch (e.g. after a 401 mid-suite).
    Log    Refreshing auth token    console=yes
    # Token is refreshed automatically inside APIClient on 401.
    # Call this keyword explicitly only if you want to force it.
    Log Framework Config
