*** Settings ***
Documentation     Shared assertion helpers and shorthand keywords used across all test suites.
Library           ../keywords/ApiKeywords.py
Library           Collections
Library           String

*** Keywords ***

# ── Response assertions ────────────────────────────────────────────────────

Assert Status 200
    [Arguments]    ${response}
    Response Status Should Be    ${response}    200

Assert Status 201
    [Arguments]    ${response}
    Response Status Should Be    ${response}    201

Assert Status 400
    [Arguments]    ${response}
    Response Status Should Be    ${response}    400

Assert Status 401
    [Arguments]    ${response}
    Response Status Should Be    ${response}    401

Assert Status 404
    [Arguments]    ${response}
    Response Status Should Be    ${response}    404

Assert Status 422
    [Arguments]    ${response}
    Response Status Should Be    ${response}    422

Assert Response Is Successful
    [Arguments]    ${response}
    Response Should Be Successful    ${response}

Assert Field Value
    [Documentation]    Assert response field equals expected value using dot-notation path.
    [Arguments]    ${response}    ${field_path}    ${expected}
    Response Field Should Equal    ${response}    ${field_path}    ${expected}

Assert Field Exists
    [Arguments]    ${response}    ${field_path}
    Response Field Should Exist    ${response}    ${field_path}

Assert List Is Not Empty
    [Arguments]    ${response}    ${field_path}
    Response List Should Not Be Empty    ${response}    ${field_path}

Assert Response Time Under
    [Documentation]    Fail if response took longer than max_ms milliseconds.
    [Arguments]    ${response}    ${max_ms}=3000
    Response Time Should Be Under    ${response}    ${max_ms}

# ── Schema validation ──────────────────────────────────────────────────────

Assert Schema
    [Documentation]    Validate response body against a named JSON Schema.
    [Arguments]    ${response}    ${schema_name}
    Validate Response Schema    ${response}    ${schema_name}

# ── Wait helpers ───────────────────────────────────────────────────────────

Wait For Status
    [Documentation]    Poll endpoint until expected_status received or timeout.
    [Arguments]    ${endpoint}    ${expected_status}    ${timeout}=60    ${interval}=3
    ${response}=    Wait Until Status Code Is    ${endpoint}    ${expected_status}
    ...             timeout=${timeout}    interval=${interval}
    [Return]    ${response}

Wait For Field Value
    [Documentation]    Poll until response body field equals expected value.
    [Arguments]    ${endpoint}    ${field_path}    ${expected_value}    ${timeout}=60    ${interval}=3
    ${response}=    Wait Until Field Value Is    ${endpoint}    ${field_path}    ${expected_value}
    ...             timeout=${timeout}    interval=${interval}
    [Return]    ${response}
