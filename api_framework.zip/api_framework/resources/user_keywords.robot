*** Settings ***
Documentation     High-level user-resource keywords used by test suites.
...               Each keyword encapsulates one user CRUD operation + its common assertions.
Library           ../keywords/ApiKeywords.py
Resource          common_keywords.robot

*** Variables ***
${USERS_ENDPOINT}      /users

*** Keywords ***

# ── CREATE ─────────────────────────────────────────────────────────────────

Create User
    [Documentation]    POST /users with given payload. Returns full APIResponse.
    [Arguments]    ${payload}
    ${response}=    Send POST Request    ${USERS_ENDPOINT}    ${payload}
    [Return]    ${response}

Create User And Verify
    [Documentation]    Create a user and assert 201 + schema validity.
    [Arguments]    ${payload}
    ${response}=    Create User    ${payload}
    Assert Status 201    ${response}
    Assert Schema    ${response}    user
    Assert Field Exists    ${response}    data.id
    [Return]    ${response}

Create Random User
    [Documentation]    Generate fake data, POST, return response.
    ${payload}=    Generate Random User Payload
    ${response}=    Create User And Verify    ${payload}
    [Return]    ${response}

# ── READ ───────────────────────────────────────────────────────────────────

Get User By ID
    [Documentation]    GET /users/{id}. Returns response.
    [Arguments]    ${user_id}
    ${response}=    Send GET Request    ${USERS_ENDPOINT}/${user_id}
    [Return]    ${response}

Get User And Verify
    [Documentation]    Fetch a user and assert 200 + schema.
    [Arguments]    ${user_id}
    ${response}=    Get User By ID    ${user_id}
    Assert Status 200    ${response}
    Assert Schema    ${response}    user
    [Return]    ${response}

Get All Users
    [Documentation]    GET /users with optional query params.
    [Arguments]    ${params}=${None}
    ${response}=    Send GET Request    ${USERS_ENDPOINT}    params=${params}
    [Return]    ${response}

Get All Users And Verify
    ${response}=    Get All Users
    Assert Status 200    ${response}
    Assert List Is Not Empty    ${response}    data
    [Return]    ${response}

# ── UPDATE ─────────────────────────────────────────────────────────────────

Update User
    [Documentation]    PUT /users/{id} with full payload.
    [Arguments]    ${user_id}    ${payload}
    ${response}=    Send PUT Request    ${USERS_ENDPOINT}/${user_id}    ${payload}
    [Return]    ${response}

Patch User
    [Documentation]    PATCH /users/{id} with partial payload.
    [Arguments]    ${user_id}    ${payload}
    ${response}=    Send PATCH Request    ${USERS_ENDPOINT}/${user_id}    ${payload}
    [Return]    ${response}

Update User And Verify
    [Arguments]    ${user_id}    ${payload}
    ${response}=    Update User    ${user_id}    ${payload}
    Assert Status 200    ${response}
    Assert Schema    ${response}    user
    [Return]    ${response}

# ── DELETE ─────────────────────────────────────────────────────────────────

Delete User
    [Documentation]    DELETE /users/{id}. Returns response.
    [Arguments]    ${user_id}
    ${response}=    Send DELETE Request    ${USERS_ENDPOINT}/${user_id}
    [Return]    ${response}

Delete User And Verify
    [Arguments]    ${user_id}
    ${response}=    Delete User    ${user_id}
    Assert Status 200    ${response}
    [Return]    ${response}

# ── HELPERS ────────────────────────────────────────────────────────────────

Extract User ID From Response
    [Documentation]    Pull the user ID from a create/get response body.
    [Arguments]    ${response}
    ${body}=      Get Response Body    ${response}
    ${user_id}=   Get JSON Field    ${body}    data    id
    [Return]      ${user_id}
