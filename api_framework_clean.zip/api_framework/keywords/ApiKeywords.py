"""
keywords/ApiKeywords.py
────────────────────────
The only Python↔Robot bridge. Every Robot keyword calls a method here.
Real logic lives in core/ and utilities/ — keywords are thin wrappers.
"""

import sys
import os
# ensure project root is on path when Robot loads this library
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from robot.api.deco import keyword, library

from config.config_loader import config
from core.api_client import APIClient
from utilities.faker_utils import FakerUtils
from utilities.json_utils import load_json, extract
from utilities.schema_validator import SchemaValidator
from utilities.response_validator import ResponseValidator
from utilities.logger import get_logger

logger = get_logger(__name__)


@library(scope="SUITE")
class ApiKeywords:

    def __init__(self):
        logger.info("ApiKeywords init | env=%s | base_url=%s", config["env"], config["base_url"])
        self._client   = APIClient()
        self._faker    = FakerUtils()
        self._schema   = SchemaValidator()
        self._validate = ResponseValidator()

    # ── HTTP request keywords ──────────────────────────────────────────────

    @keyword("Send GET Request")
    def send_get_request(self, endpoint, params=None, extra_headers=None):
        logger.info("KW | Send GET Request | %s", endpoint)
        return self._client.send("GET", endpoint, params=params, extra_headers=extra_headers)

    @keyword("Send POST Request")
    def send_post_request(self, endpoint, body, extra_headers=None):
        logger.info("KW | Send POST Request | %s", endpoint)
        return self._client.send("POST", endpoint, body=body, extra_headers=extra_headers)

    @keyword("Send PUT Request")
    def send_put_request(self, endpoint, body, extra_headers=None):
        logger.info("KW | Send PUT Request | %s", endpoint)
        return self._client.send("PUT", endpoint, body=body, extra_headers=extra_headers)

    @keyword("Send PATCH Request")
    def send_patch_request(self, endpoint, body, extra_headers=None):
        logger.info("KW | Send PATCH Request | %s", endpoint)
        return self._client.send("PATCH", endpoint, body=body, extra_headers=extra_headers)

    @keyword("Send DELETE Request")
    def send_delete_request(self, endpoint, extra_headers=None):
        logger.info("KW | Send DELETE Request | %s", endpoint)
        return self._client.send("DELETE", endpoint, extra_headers=extra_headers)

    @keyword("Send Unauthenticated GET Request")
    def send_unauthenticated_get(self, endpoint):
        logger.info("KW | Unauthenticated GET | %s", endpoint)
        return self._client.send("GET", endpoint, auth=False)

    # ── wait keywords ──────────────────────────────────────────────────────

    @keyword("Wait Until Status Code Is")
    def wait_until_status_code_is(self, endpoint, expected_status,
                                   timeout=60, interval=3, method="GET", body=None):
        expected_status = int(expected_status)
        return self._client.wait_until(
            method, endpoint,
            condition=lambda r: r.status_code == expected_status,
            timeout=int(timeout), interval=int(interval), body=body,
        )

    @keyword("Wait Until Field Value Is")
    def wait_until_field_value_is(self, endpoint, field_path, expected_value,
                                   timeout=60, interval=3):
        keys = field_path.split(".")
        def condition(r):
            try:
                return extract(r.json(), *keys) == expected_value
            except Exception:
                return False
        return self._client.wait_until(
            "GET", endpoint, condition=condition,
            timeout=int(timeout), interval=int(interval),
        )

    # ── assertion keywords ─────────────────────────────────────────────────

    @keyword("Response Status Should Be")
    def response_status_should_be(self, response, expected_status):
        self._validate.assert_status(response, int(expected_status))

    @keyword("Response Should Be Successful")
    def response_should_be_successful(self, response):
        self._validate.assert_success(response)

    @keyword("Response Field Should Equal")
    def response_field_should_equal(self, response, field_path, expected):
        self._validate.assert_field_equals(response, field_path, expected)

    @keyword("Response Field Should Exist")
    def response_field_should_exist(self, response, field_path):
        self._validate.assert_field_exists(response, field_path)

    @keyword("Response List Should Not Be Empty")
    def response_list_should_not_be_empty(self, response, field_path):
        self._validate.assert_list_not_empty(response, field_path)

    @keyword("Response Time Should Be Under")
    def response_time_should_be_under(self, response, max_ms):
        self._validate.assert_response_time(response, float(max_ms))

    @keyword("Validate Response Schema")
    def validate_response_schema(self, response, schema_name):
        self._schema.validate(response.json(), schema_name)

    # ── data & payload keywords ────────────────────────────────────────────

    @keyword("Generate Random User Payload")
    def generate_random_user_payload(self, role="user"):
        return self._faker.random_user_payload(role=role)

    @keyword("Generate Random Email")
    def generate_random_email(self):
        return self._faker.random_email()

    @keyword("Generate Random UUID")
    def generate_random_uuid(self):
        return self._faker.random_uuid()

    @keyword("Build Payload")
    def build_payload(self, **kwargs):
        return dict(kwargs)

    @keyword("Load JSON File")
    def load_json_file(self, path):
        return load_json(path)

    # ── response helper keywords ───────────────────────────────────────────

    @keyword("Get Response Body")
    def get_response_body(self, response):
        return response.json()

    @keyword("Get Response Status Code")
    def get_response_status_code(self, response):
        return response.status_code

    @keyword("Get JSON Field")
    def get_json_field(self, data, *keys):
        return extract(data, *keys)

    # ── config keywords ────────────────────────────────────────────────────

    @keyword("Get Current Environment")
    def get_current_environment(self):
        return config["env"]

    @keyword("Get Base URL")
    def get_base_url(self):
        return config["base_url"]

    @keyword("Log Framework Config")
    def log_framework_config(self):
        logger.info("Config | env=%s | base_url=%s | timeout=%ds | retries=%d",
                    config["env"], config["base_url"],
                    config["timeout"], config["retries"])
