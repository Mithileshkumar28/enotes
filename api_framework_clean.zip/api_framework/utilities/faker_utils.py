"""
utilities/faker_utils.py  —  random test data
"""

import uuid
from faker import Faker
from utilities.logger import get_logger

logger  = get_logger(__name__)
_faker  = Faker()


class FakerUtils:

    @staticmethod
    def random_email() -> str:
        return _faker.unique.email()

    @staticmethod
    def random_name() -> str:
        return _faker.name()

    @staticmethod
    def random_uuid() -> str:
        return str(uuid.uuid4())

    @staticmethod
    def random_user_payload(role: str = "user") -> dict:
        payload = {
            "first_name": _faker.first_name(),
            "last_name":  _faker.last_name(),
            "email":      _faker.unique.email(),
            "phone":      _faker.phone_number(),
            "role":       role,
        }
        logger.debug("Generated user payload: %s", payload)
        return payload
