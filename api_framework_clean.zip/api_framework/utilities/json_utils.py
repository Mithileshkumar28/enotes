"""
utilities/json_utils.py  —  load, save, extract nested values from dicts
"""

import json
from pathlib import Path
from utilities.logger import get_logger

logger = get_logger(__name__)


def load_json(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"File not found: {path}")
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json(data: dict, path: str) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def extract(data: dict, *keys, default=None):
    """Safely get a nested value.  extract(body, 'data', 'id')"""
    current = data
    for key in keys:
        if not isinstance(current, dict):
            return default
        current = current.get(key, default)
        if current is default:
            return default
    return current
