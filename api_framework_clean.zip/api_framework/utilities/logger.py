"""
utilities/logger.py
────────────────────
Sets up logging automatically the moment this module is imported.
Works whether you run a Robot suite, a Python script, or a unit test.

Every module uses:
    from utilities.logger import get_logger
    logger = get_logger(__name__)

Log output goes to:
    - Console (stdout)
    - reports/<env>.log  (created automatically)

Log format:
    2024-01-15 12:34:56 | INFO     | core.api_client          | message here
"""

import logging
import sys
from pathlib import Path

from config.config_loader import config

_configured = False


def setup_logging():
    global _configured
    if _configured:
        return

    level = getattr(logging, config["log_level"].upper(), logging.INFO)

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)-30s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root = logging.getLogger()
    root.setLevel(level)

    # console
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(level)
    console.setFormatter(formatter)
    root.addHandler(console)

    # file
    log_path = Path(config["log_file"])
    log_path.parent.mkdir(parents=True, exist_ok=True)
    file_handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")
    file_handler.setLevel(level)
    file_handler.setFormatter(formatter)
    root.addHandler(file_handler)

    _configured = True
    root.info("Logging started | env=%s | level=%s | file=%s",
              config["env"], config["log_level"], config["log_file"])


def get_logger(name: str) -> logging.Logger:
    setup_logging()
    return logging.getLogger(name)


# auto-setup the moment this file is imported
setup_logging()
