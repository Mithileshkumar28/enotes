"""
utilities/schema_validator.py  —  validate response body against a JSON Schema file
"""

import json
from pathlib import Path
import jsonschema
from utilities.logger import get_logger

logger     = get_logger(__name__)
SCHEMA_DIR = Path(__file__).parent.parent / "testdata" / "schemas"


class SchemaValidator:

    def validate(self, data: dict, schema_name: str) -> None:
        """Validate data against testdata/schemas/<schema_name>.json"""
        name   = schema_name if schema_name.endswith(".json") else f"{schema_name}.json"
        path   = SCHEMA_DIR / name
        if not path.exists():
            raise FileNotFoundError(f"Schema not found: {path}")

        with open(path) as f:
            schema = json.load(f)

        logger.info("Validating against schema: %s", name)
        try:
            jsonschema.validate(instance=data, schema=schema)
            logger.info("Schema validation PASSED ✓")
        except jsonschema.ValidationError as e:
            logger.error("Schema validation FAILED ✗ | %s", e.message)
            raise
