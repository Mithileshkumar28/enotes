"""
utilities/response_validator.py  —  assertion helpers for APIResponse
"""

from utilities.logger import get_logger
from utilities.json_utils import extract

logger = get_logger(__name__)


class ResponseValidator:

    def assert_status(self, response, expected: int) -> None:
        logger.info("Assert status | expected=%d actual=%d", expected, response.status_code)
        assert response.status_code == expected, (
            f"Expected {expected}, got {response.status_code}\nBody: {response.body}"
        )

    def assert_success(self, response) -> None:
        assert response.ok, f"Expected 2xx, got {response.status_code}\nBody: {response.body}"

    def assert_field_equals(self, response, field_path: str, expected) -> None:
        actual = extract(response.json(), *field_path.split("."))
        logger.info("Assert '%s' == '%s' (got '%s')", field_path, expected, actual)
        assert actual == expected, (
            f"Field '{field_path}': expected '{expected}', got '{actual}'"
        )

    def assert_field_exists(self, response, field_path: str) -> None:
        _MISS  = object()
        actual = extract(response.json(), *field_path.split("."), default=_MISS)
        assert actual is not _MISS, f"Field '{field_path}' missing from response"

    def assert_list_not_empty(self, response, field_path: str) -> None:
        actual = extract(response.json(), *field_path.split("."))
        assert isinstance(actual, list) and len(actual) > 0, (
            f"Field '{field_path}' is not a non-empty list, got: {actual!r}"
        )

    def assert_response_time(self, response, max_ms: float) -> None:
        logger.info("Assert response time | %.0fms <= %.0fms", response.elapsed_ms, max_ms)
        assert response.elapsed_ms <= max_ms, (
            f"Response too slow: {response.elapsed_ms:.0f}ms > {max_ms:.0f}ms"
        )
