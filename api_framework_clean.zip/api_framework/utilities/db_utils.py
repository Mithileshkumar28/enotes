"""
utilities/db_utils.py
──────────────────────
PostgreSQL helpers. Defined here but NOT called from any test by default.
To use: set DB_HOST, DB_NAME, DB_USER, DB_PASSWORD env vars,
        then create DBUtils() inside a keyword.
"""

import os
from utilities.logger import get_logger

logger = get_logger(__name__)


class DBUtils:

    def __init__(self):
        from sqlalchemy import create_engine, text
        self._text   = text
        host         = os.environ.get("DB_HOST", "localhost")
        port         = os.environ.get("DB_PORT", "5432")
        db           = os.environ.get("DB_NAME", "testdb")
        user         = os.environ.get("DB_USER", "postgres")
        password     = os.environ.get("DB_PASSWORD", "")
        dsn          = f"postgresql+psycopg2://{user}:{password}@{host}:{port}/{db}"
        self._engine = create_engine(dsn, pool_pre_ping=True)
        logger.info("DBUtils connected to %s:%s/%s", host, port, db)

    def fetch_one(self, sql: str, params: tuple = ()) -> dict:
        with self._engine.connect() as conn:
            row = conn.execute(self._text(sql), params).mappings().first()
            return dict(row) if row else None

    def assert_row_exists(self, sql: str, params: tuple = ()) -> dict:
        row = self.fetch_one(sql, params)
        assert row is not None, f"No DB row found for: {sql}"
        logger.info("DB assert_row_exists PASSED ✓")
        return row
