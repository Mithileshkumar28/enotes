*** Settings ***
Library    ../keywords/ApiKeywords.py

*** Keywords ***

Assert Status 200
    [Arguments]    ${response}
    Response Status Should Be    ${response}    200

Assert Status 201
    [Arguments]    ${response}
    Response Status Should Be    ${response}    201

Assert Status 400
    [Arguments]    ${response}
    Response Status Should Be    ${response}    400

Assert Status 401
    [Arguments]    ${response}
    Response Status Should Be    ${response}    401

Assert Status 404
    [Arguments]    ${response}
    Response Status Should Be    ${response}    404

Assert Field Value
    [Arguments]    ${response}    ${field_path}    ${expected}
    Response Field Should Equal    ${response}    ${field_path}    ${expected}

Assert Schema
    [Arguments]    ${response}    ${schema_name}
    Validate Response Schema    ${response}    ${schema_name}

Wait For Status
    [Arguments]    ${endpoint}    ${expected_status}    ${timeout}=60    ${interval}=3
    ${response}=    Wait Until Status Code Is    ${endpoint}    ${expected_status}
    ...             timeout=${timeout}    interval=${interval}
    [Return]    ${response}

Wait For Field Value
    [Arguments]    ${endpoint}    ${field_path}    ${expected_value}    ${timeout}=60    ${interval}=3
    ${response}=    Wait Until Field Value Is    ${endpoint}    ${field_path}    ${expected_value}
    ...             timeout=${timeout}    interval=${interval}
    [Return]    ${response}
