*** Settings ***
Library    ../keywords/ApiKeywords.py
Resource   common_keywords.robot

*** Variables ***
${USERS_ENDPOINT}    /users

*** Keywords ***

Create User
    [Arguments]    ${payload}
    ${response}=    Send POST Request    ${USERS_ENDPOINT}    ${payload}
    [Return]    ${response}

Create User And Verify
    [Arguments]    ${payload}
    ${response}=    Create User    ${payload}
    Assert Status 201    ${response}
    Assert Schema    ${response}    user
    Response Field Should Exist    ${response}    data.id
    [Return]    ${response}

Create Random User
    ${payload}=     Generate Random User Payload
    ${response}=    Create User And Verify    ${payload}
    [Return]    ${response}

Get User By ID
    [Arguments]    ${user_id}
    ${response}=    Send GET Request    ${USERS_ENDPOINT}/${user_id}
    [Return]    ${response}

Get User And Verify
    [Arguments]    ${user_id}
    ${response}=    Get User By ID    ${user_id}
    Assert Status 200    ${response}
    Assert Schema    ${response}    user
    [Return]    ${response}

Get All Users
    [Arguments]    ${params}=${None}
    ${response}=    Send GET Request    ${USERS_ENDPOINT}    params=${params}
    [Return]    ${response}

Update User
    [Arguments]    ${user_id}    ${payload}
    ${response}=    Send PUT Request    ${USERS_ENDPOINT}/${user_id}    ${payload}
    [Return]    ${response}

Patch User
    [Arguments]    ${user_id}    ${payload}
    ${response}=    Send PATCH Request    ${USERS_ENDPOINT}/${user_id}    ${payload}
    [Return]    ${response}

Delete User
    [Arguments]    ${user_id}
    ${response}=    Send DELETE Request    ${USERS_ENDPOINT}/${user_id}
    [Return]    ${response}

Extract User ID
    [Arguments]    ${response}
    ${body}=      Get Response Body       ${response}
    ${user_id}=   Get JSON Field          ${body}    data    id
    [Return]    ${user_id}
