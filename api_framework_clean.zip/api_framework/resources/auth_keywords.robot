*** Settings ***
Library    ../keywords/ApiKeywords.py

*** Keywords ***

Setup API Session
    Log Framework Config
    ${env}=    Get Current Environment
    Log    Environment: ${env}    console=yes
