*** Settings ***
Library      ../../keywords/ApiKeywords.py
Resource     ../../resources/auth_keywords.robot
Resource     ../../resources/common_keywords.robot
Resource     ../../resources/user_keywords.robot
Suite Setup  Setup API Session
Test Tags    integration

*** Test Cases ***

TC_I001 — Full User Lifecycle
    ${payload}=    Generate Random User Payload
    ${create}=     Create User And Verify    ${payload}
    ${user_id}=    Extract User ID    ${create}

    ${get}=        Get User And Verify    ${user_id}
    Assert Field Value    ${get}    data.id    ${user_id}

    ${update}=     Generate Random User Payload    role=admin
    ${upd_resp}=   Update User    ${user_id}    ${update}
    Assert Status 200    ${upd_resp}
    Assert Field Value    ${upd_resp}    data.role    admin

    Delete User    ${user_id}
    ${gone}=       Get User By ID    ${user_id}
    Assert Status 404    ${gone}

TC_I002 — Wait Until User Status Is Active
    ${create}=     Create Random User
    ${user_id}=    Extract User ID    ${create}
    ${response}=   Wait For Field Value
    ...            endpoint=/users/${user_id}
    ...            field_path=data.status
    ...            expected_value=active
    ...            timeout=30    interval=3
    Assert Status 200    ${response}

TC_I003 — Patch Email Then Role, Both Persist
    ${create}=     Create Random User
    ${user_id}=    Extract User ID    ${create}

    ${new_email}=  Generate Random Email
    Patch User     ${user_id}    ${{{"email": "${new_email}"}}}

    Patch User     ${user_id}    ${{{"role": "editor"}}}

    ${final}=      Get User And Verify    ${user_id}
    Assert Field Value    ${final}    data.email    ${new_email}
    Assert Field Value    ${final}    data.role     editor
