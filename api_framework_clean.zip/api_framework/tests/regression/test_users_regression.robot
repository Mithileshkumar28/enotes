*** Settings ***
Library      ../../keywords/ApiKeywords.py
Resource     ../../resources/auth_keywords.robot
Resource     ../../resources/common_keywords.robot
Resource     ../../resources/user_keywords.robot
Library      Collections
Suite Setup  Setup API Session
Test Tags    regression

*** Test Cases ***

TC_R001 — Get All Users Returns Non-Empty List
    ${response}=    Get All Users
    Assert Status 200    ${response}
    Response List Should Not Be Empty    ${response}    data

TC_R002 — Create User With Valid Payload Returns 201
    ${payload}=     Generate Random User Payload
    ${response}=    Create User    ${payload}
    Assert Status 201    ${response}

TC_R003 — Create User Response Contains ID
    ${response}=    Create Random User
    Response Field Should Exist    ${response}    data.id

TC_R004 — Created User Email Matches Payload
    ${payload}=     Generate Random User Payload
    ${email}=       Get From Dictionary    ${payload}    email
    ${response}=    Create User And Verify    ${payload}
    Assert Field Value    ${response}    data.email    ${email}

TC_R005 — Get User Returns Correct ID
    ${create}=      Create Random User
    ${user_id}=     Extract User ID    ${create}
    ${response}=    Get User And Verify    ${user_id}
    Assert Field Value    ${response}    data.id    ${user_id}

TC_R006 — Get Non-Existent User Returns 404
    ${response}=    Get User By ID    non-existent-000
    Assert Status 404    ${response}

TC_R007 — Update User Returns 200
    ${create}=      Create Random User
    ${user_id}=     Extract User ID    ${create}
    ${payload}=     Generate Random User Payload    role=admin
    ${response}=    Update User    ${user_id}    ${payload}
    Assert Status 200    ${response}
    Assert Field Value    ${response}    data.role    admin

TC_R008 — Patch User Email
    ${create}=      Create Random User
    ${user_id}=     Extract User ID    ${create}
    ${new_email}=   Generate Random Email
    ${patch}=       Build Payload    email=${new_email}
    ${response}=    Patch User    ${user_id}    ${patch}
    Assert Status 200    ${response}
    Assert Field Value    ${response}    data.email    ${new_email}

TC_R009 — Delete User Returns 200
    ${create}=      Create Random User
    ${user_id}=     Extract User ID    ${create}
    ${response}=    Delete User    ${user_id}
    Assert Status 200    ${response}

TC_R010 — Deleted User Returns 404
    ${create}=      Create Random User
    ${user_id}=     Extract User ID    ${create}
    Delete User    ${user_id}
    ${response}=    Get User By ID    ${user_id}
    Assert Status 404    ${response}

TC_R011 — Missing Required Field Returns 400
    ${payload}=     Build Payload    role=user
    ${response}=    Create User    ${payload}
    Assert Status 400    ${response}

TC_R012 — Invalid Email Returns 422
    ${payload}=     Build Payload    email=not-valid    first_name=Test    last_name=User    role=user
    ${response}=    Create User    ${payload}
    Response Status Should Be    ${response}    422

TC_R013 — Schema Validation On Create
    ${response}=    Create Random User
    Assert Schema    ${response}    user

TC_R014 — Response Time Within Limit
    ${response}=    Send GET Request    /users
    Response Time Should Be Under    ${response}    3000

TC_R015 — Get Users Supports Pagination
    ${params}=      Create Dictionary    page=1    limit=5
    ${response}=    Get All Users    params=${params}
    Assert Status 200    ${response}
