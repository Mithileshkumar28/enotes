@echo off
:: Usage:
::   run.bat               → qa, all suites
::   run.bat dev           → dev, all suites
::   run.bat prod          → prod, smoke only
::   run.bat qa smoke      → qa, smoke only
::   run.bat qa regression → qa, regression only

SET PROJECT_ROOT=%~dp0
IF "%PROJECT_ROOT:~-1%"=="\" SET PROJECT_ROOT=%PROJECT_ROOT:~0,-1%

:: ── environment ────────────────────────────────────────────────────────────
SET ENV=%1
IF "%ENV%"=="" SET ENV=qa
SET FRAMEWORK_ENV=%ENV%
SET PYTHONPATH=%PROJECT_ROOT%

echo [run.bat] env=%FRAMEWORK_ENV%  root=%PROJECT_ROOT%

:: ── suite ──────────────────────────────────────────────────────────────────
SET SUITE=%2
SET OUTPUT=%PROJECT_ROOT%\reports\%ENV%
IF NOT EXIST "%OUTPUT%" mkdir "%OUTPUT%"

SET CMD=python -m robot --outputdir "%OUTPUT%" --loglevel DEBUG --pythonpath "%PROJECT_ROOT%"

IF "%ENV%"=="prod"          SET CMD=%CMD% "%PROJECT_ROOT%\tests\smoke\"       & GOTO RUN
IF "%SUITE%"=="smoke"       SET CMD=%CMD% "%PROJECT_ROOT%\tests\smoke\"       & GOTO RUN
IF "%SUITE%"=="regression"  SET CMD=%CMD% "%PROJECT_ROOT%\tests\regression\"  & GOTO RUN
IF "%SUITE%"=="integration" SET CMD=%CMD% "%PROJECT_ROOT%\tests\integration\" & GOTO RUN
SET CMD=%CMD% "%PROJECT_ROOT%\tests\"

:RUN
echo [run.bat] %CMD%
%CMD%
EXIT /B %ERRORLEVEL%
