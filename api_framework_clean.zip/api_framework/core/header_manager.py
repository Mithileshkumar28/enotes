"""
core/header_manager.py
───────────────────────
One job: return the common headers dict for every request.

To ADD a header for all requests    → add it inside get_headers()
To REMOVE a header                  → delete it from get_headers()
To add a header for one request     → pass extra={"X-Custom": "value"}
To remove a header for one request  → pass exclude=["Accept-Language"]

Usage:
    hm = HeaderManager()
    headers = hm.get_headers()
    headers = hm.get_headers(extra={"X-Correlation-Id": "abc"})
    headers = hm.get_headers(exclude=["Authorization"])
"""

import uuid
from core.token_manager import TokenManager
from utilities.logger import get_logger

logger = get_logger(__name__)


class HeaderManager:

    def __init__(self):
        self._token_manager = TokenManager()

    def get_headers(self, extra: dict = None, exclude: list = None) -> dict:
        """
        Returns the common headers for every API request.

        ── ADD or REMOVE permanent headers inside this dict ──
        """
        headers = {
            "Authorization":   f"Bearer {self._token_manager.get_token()}",
            "Content-Type":    "application/json",
            "Accept":          "application/json",
            "X-Request-Id":    str(uuid.uuid4()),
        }

        if extra:
            headers.update(extra)

        if exclude:
            for key in exclude:
                headers.pop(key, None)

        logger.debug("Headers prepared | keys=%s", list(headers.keys()))
        return headers
