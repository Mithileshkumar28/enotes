"""
core/api_client.py
───────────────────
Sends HTTP requests and returns a clean APIResponse.

Features:
  - Uses HeaderManager to get common headers automatically
  - Auto-refreshes token on 401 (one retry)
  - Dynamic wait: poll until a condition is met
  - Logs every request and response
"""

import time
import requests
from config.config_loader import config
from core.header_manager import HeaderManager
from utilities.logger import get_logger

logger = get_logger(__name__)


class APIResponse:
    """Simple wrapper around the raw requests response."""

    def __init__(self, raw: requests.Response, elapsed_ms: float):
        self.status_code = raw.status_code
        self.elapsed_ms  = elapsed_ms
        self.headers     = dict(raw.headers)
        self.url         = raw.url
        self._raw        = raw

        try:
            self.body = raw.json()
        except Exception:
            self.body = raw.text

    @property
    def ok(self) -> bool:
        return 200 <= self.status_code < 300

    def json(self):
        return self.body

    def __str__(self):
        return f"{self.status_code} | {self._raw.request.method} {self.url} | {self.elapsed_ms:.0f}ms"


class APIClient:

    def __init__(self):
        self._headers  = HeaderManager()
        self._session  = requests.Session()

    # ── main send ──────────────────────────────────────────────────────────

    def send(self, method: str, endpoint: str, body: dict = None,
             params: dict = None, extra_headers: dict = None,
             exclude_headers: list = None, auth: bool = True) -> APIResponse:
        """
        Send an HTTP request.

        Args:
            method          : GET / POST / PUT / PATCH / DELETE
            endpoint        : e.g. "/users/123"
            body            : dict for JSON body (optional)
            params          : query string params (optional)
            extra_headers   : extra headers to add for this request only
            exclude_headers : header keys to remove for this request only
            auth            : set False to skip Authorization header
        """
        url     = config["base_url"] + "/" + endpoint.lstrip("/")
        headers = self._headers.get_headers(
            extra   = extra_headers,
            exclude = (exclude_headers or []) + ([] if auth else ["Authorization"]),
        )

        logger.info("→ %s %s", method.upper(), url)

        start = time.time()
        try:
            raw = self._session.request(
                method  = method.upper(),
                url     = url,
                headers = headers,
                json    = body,
                params  = params,
                timeout = config["timeout"],
            )
        except requests.exceptions.Timeout:
            logger.error("Request TIMED OUT | %s %s", method.upper(), url)
            raise
        except requests.exceptions.ConnectionError as e:
            logger.error("Connection error | %s %s | %s", method.upper(), url, e)
            raise

        elapsed_ms = (time.time() - start) * 1000
        response   = APIResponse(raw, elapsed_ms)

        # auto-retry once on 401 with a fresh token
        if response.status_code == 401 and auth:
            logger.warning("401 received — refreshing token and retrying once")
            self._headers._token_manager.invalidate()
            headers = self._headers.get_headers(extra=extra_headers, exclude=exclude_headers)
            raw     = self._session.request(
                method=method.upper(), url=url, headers=headers,
                json=body, params=params, timeout=config["timeout"],
            )
            response = APIResponse(raw, (time.time() - start) * 1000)

        log_fn = logger.info if response.ok else logger.warning
        log_fn("← %s", response)

        return response

    # ── dynamic wait ───────────────────────────────────────────────────────

    def wait_until(self, method: str, endpoint: str, condition,
                   timeout: int = 60, interval: int = 3,
                   body: dict = None, params: dict = None) -> APIResponse:
        """
        Poll endpoint every `interval` seconds until condition(response) is True
        or `timeout` seconds elapse.

        Examples:
            client.wait_until("GET", "/jobs/1",
                condition=lambda r: r.status_code == 200,
                timeout=30, interval=3)

            client.wait_until("GET", "/users/1",
                condition=lambda r: r.json().get("status") == "active",
                timeout=60, interval=5)
        """
        deadline = time.time() + timeout
        attempt  = 0

        logger.info("Waiting | %s %s | timeout=%ds interval=%ds",
                    method.upper(), endpoint, timeout, interval)

        while time.time() < deadline:
            attempt += 1
            resp = self.send(method, endpoint, body=body, params=params)

            if condition(resp):
                logger.info("Condition met after %d attempt(s) | %s", attempt, resp)
                return resp

            remaining = deadline - time.time()
            if remaining > 0:
                time.sleep(min(interval, remaining))

        raise TimeoutError(
            f"Condition not met within {timeout}s after {attempt} attempt(s) "
            f"on {method.upper()} {endpoint}"
        )
