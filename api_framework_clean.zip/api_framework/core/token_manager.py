"""
core/token_manager.py
──────────────────────
One job: return a valid Bearer token.

- First call  → fetches from auth endpoint, caches it
- Next calls  → returns the cached token (until it expires)
- On 401      → call invalidate(), next get_token() fetches fresh

Usage:
    tm = TokenManager()
    token = tm.get_token()   # returns plain string e.g. "eyJhbGc..."
"""

import time
import requests
from config.config_loader import config
from utilities.logger import get_logger

logger = get_logger(__name__)


class TokenManager:

    def __init__(self):
        self._token      = None
        self._expires_at = 0.0        # unix timestamp when token expires
        self._buffer     = 30         # refresh 30s before actual expiry

    def get_token(self) -> str:
        """Return a valid token. Fetches a new one only when expired."""
        if self._token and time.time() < (self._expires_at - self._buffer):
            logger.debug("Token cache HIT (expires in %.0fs)", self._expires_at - time.time())
            return self._token

        logger.info("Fetching new token from %s", config["token_url"])
        return self._fetch()

    def invalidate(self):
        """Force re-fetch on next get_token() call (use after 401)."""
        logger.info("Token invalidated — will re-fetch on next request")
        self._token      = None
        self._expires_at = 0.0

    def _fetch(self) -> str:
        payload = {
            "grant_type":    config["grant_type"],
            "client_id":     config["client_id"],
            "client_secret": config["client_secret"],
        }
        try:
            resp = requests.post(config["token_url"], data=payload, timeout=config["timeout"])
            resp.raise_for_status()
        except requests.exceptions.RequestException as e:
            logger.error("Token fetch FAILED: %s", e)
            raise

        body             = resp.json()
        self._token      = body["access_token"]
        expires_in       = int(body.get("expires_in", 3600))
        self._expires_at = time.time() + expires_in

        logger.info("Token fetched OK | expires_in=%ds", expires_in)
        return self._token
