"""
config/config_loader.py
────────────────────────
Loads the correct YAML file based on FRAMEWORK_ENV env variable.
Default environment is qa.

Change environment:
    set FRAMEWORK_ENV=dev    (Windows)
    export FRAMEWORK_ENV=dev (Linux/Mac)

Every module imports like this:
    from config.config_loader import config
    print(config.base_url)
"""

import os
import yaml
from pathlib import Path

_CONFIG_DIR  = Path(__file__).parent
_DEFAULT_ENV = "qa"                          # ← change default here if needed


def _load_config() -> dict:
    env      = os.environ.get("FRAMEWORK_ENV", _DEFAULT_ENV).strip().lower()
    cfg_file = _CONFIG_DIR / f"{env}.yaml"

    if not cfg_file.exists():
        raise FileNotFoundError(f"Config file not found: {cfg_file}")

    with open(cfg_file, "r") as f:
        data = yaml.safe_load(f)

    # flatten for easy access
    cfg = {
        "env":           data["env"],
        "base_url":      data["base_url"].rstrip("/"),
        "token_url":     data["base_url"].rstrip("/") + data["auth"]["token_url"],
        "client_id":     data["auth"]["client_id"],
        "client_secret": data["auth"]["client_secret"],
        "grant_type":    data["auth"]["grant_type"],
        "log_level":     data["logging"]["level"],
        "log_file":      data["logging"]["log_file"],
        "timeout":       int(data["http"]["timeout"]),
        "retries":       int(data["http"]["retries"]),
    }
    return cfg


# Single dict accessible everywhere — loaded once at import time
config = _load_config()
