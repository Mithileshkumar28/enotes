@echo off
:: ═══════════════════════════════════════════════════════════════════════════
::  run_python.bat — Run any Python file with correct PYTHONPATH
::
::  Usage:
::    run_python.bat core\token_manager.py
::    run_python.bat core\api_client.py
::    run_python.bat utilities\faker_utils.py
::
::  Why this exists:
::    Running `python core\token_manager.py` directly fails because Python
::    doesn't know where config\ or utilities\ are.
::    This script sets PYTHONPATH to the project root first.
:: ═══════════════════════════════════════════════════════════════════════════

SET PROJECT_ROOT=%~dp0
IF "%PROJECT_ROOT:~-1%"=="\" SET PROJECT_ROOT=%PROJECT_ROOT:~0,-1%

SET PYTHONPATH=%PROJECT_ROOT%;%PYTHONPATH%
SET FRAMEWORK_ENV=%2
IF "%FRAMEWORK_ENV%"=="" SET FRAMEWORK_ENV=qa

echo [run_python] PYTHONPATH = %PROJECT_ROOT%
echo [run_python] FRAMEWORK_ENV = %FRAMEWORK_ENV%
echo [run_python] Running: python %1
echo ───────────────────────────────────────────────────
python "%PROJECT_ROOT%\%1"
