@echo off
:: ═══════════════════════════════════════════════════════════════════════════
::  run.bat — API Test Framework Runner
::  Usage:
::    run.bat                   → qa environment, all suites
::    run.bat dev               → dev environment, all suites
::    run.bat prod              → prod environment, smoke only
::    run.bat qa smoke          → qa + smoke suite only
::    run.bat qa regression     → qa + regression suite only
::    run.bat qa integration    → qa + integration suite only
:: ═══════════════════════════════════════════════════════════════════════════

:: ── 1. Resolve project root (directory this .bat lives in) ─────────────────
SET PROJECT_ROOT=%~dp0
:: Remove trailing backslash
IF "%PROJECT_ROOT:~-1%"=="\" SET PROJECT_ROOT=%PROJECT_ROOT:~0,-1%

:: ── 2. Add project root to PYTHONPATH so all imports resolve ───────────────
::    This fixes: ModuleNotFoundError: No module named 'config'
SET PYTHONPATH=%PROJECT_ROOT%;%PYTHONPATH%
echo [run.bat] PYTHONPATH=%PYTHONPATH%

:: ── 3. Environment (default: qa) ───────────────────────────────────────────
SET ENV=%1
IF "%ENV%"=="" SET ENV=qa

IF NOT "%ENV%"=="dev" IF NOT "%ENV%"=="qa" IF NOT "%ENV%"=="prod" (
    echo [ERROR] Unknown environment: %ENV%
    echo         Valid values: dev ^| qa ^| prod
    EXIT /B 1
)

SET FRAMEWORK_ENV=%ENV%
echo [run.bat] Environment: %FRAMEWORK_ENV%

:: ── 4. Suite filter (default: all) ─────────────────────────────────────────
SET SUITE=%2
IF "%SUITE%"=="" SET SUITE=all

:: ── 5. Output directory ────────────────────────────────────────────────────
SET OUTPUT_DIR=%PROJECT_ROOT%\reports\%ENV%
IF NOT EXIST "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"

:: ── 6. Build robot command ─────────────────────────────────────────────────
SET RF_CMD=python -m robot --outputdir "%OUTPUT_DIR%" --loglevel DEBUG --pythonpath "%PROJECT_ROOT%"

IF "%SUITE%"=="smoke"       SET RF_CMD=%RF_CMD% "%PROJECT_ROOT%\tests\smoke\"       & GOTO RUN
IF "%SUITE%"=="regression"  SET RF_CMD=%RF_CMD% "%PROJECT_ROOT%\tests\regression\"  & GOTO RUN
IF "%SUITE%"=="integration" SET RF_CMD=%RF_CMD% "%PROJECT_ROOT%\tests\integration\" & GOTO RUN

:: prod → smoke only (hard rule)
IF "%ENV%"=="prod" (
    echo [run.bat] PROD env — running smoke suite only
    SET RF_CMD=%RF_CMD% "%PROJECT_ROOT%\tests\smoke\"
    GOTO RUN
)

:: default: all suites
SET RF_CMD=%RF_CMD% "%PROJECT_ROOT%\tests\"

:RUN
echo [run.bat] Running: %RF_CMD%
echo ───────────────────────────────────────────────────────────────────────
%RF_CMD%
SET EXIT_CODE=%ERRORLEVEL%
echo ───────────────────────────────────────────────────────────────────────
echo [run.bat] Reports : %OUTPUT_DIR%\
echo [run.bat] Exit code: %EXIT_CODE%
EXIT /B %EXIT_CODE%
