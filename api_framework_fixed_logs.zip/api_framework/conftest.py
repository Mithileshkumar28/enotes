"""
conftest.py  (project root)
────────────────────────────
Automatically loaded by pytest before any test.
Also imported by run.bat / robot via PYTHONPATH trick.

PRIMARY JOB: add the project root to sys.path so that every import works
regardless of which directory you launch from.

  from config.config_loader import config    ✓
  from core.api_client import APIClient      ✓
  from utilities.logger import get_logger    ✓

Without this, running:
    python core/token_manager.py
    python -m pytest tests/
    robot tests/smoke/
all fail with ModuleNotFoundError.
"""

import sys
from pathlib import Path

# Resolve the absolute path of this file's directory (= project root)
_PROJECT_ROOT = Path(__file__).resolve().parent

# Add it to the front of sys.path — only if not already there
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))
