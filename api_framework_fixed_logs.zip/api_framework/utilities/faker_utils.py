"""
utilities/faker_utils.py
─────────────────────────
Random test-data generators backed by the Faker library.
Only helpers actually used in Robot keywords are included.

Usage:
    from utilities.faker_utils import FakerUtils
    fu = FakerUtils()
    email = fu.random_email()
    payload = fu.random_user_payload()
"""

import uuid
from faker import Faker

from utilities.logger import get_logger

logger = get_logger(__name__)

_faker = Faker()   # module-level singleton — fast, thread-safe for reads


class FakerUtils:
    """Static-style helpers; instantiate once per test suite."""

    # ── primitives ─────────────────────────────────────────────────────────

    @staticmethod
    def random_name() -> str:
        name = _faker.name()
        logger.debug("FakerUtils.random_name → %s", name)
        return name

    @staticmethod
    def random_first_name() -> str:
        return _faker.first_name()

    @staticmethod
    def random_last_name() -> str:
        return _faker.last_name()

    @staticmethod
    def random_email() -> str:
        email = _faker.unique.email()
        logger.debug("FakerUtils.random_email → %s", email)
        return email

    @staticmethod
    def random_phone() -> str:
        return _faker.phone_number()

    @staticmethod
    def random_uuid() -> str:
        return str(uuid.uuid4())

    @staticmethod
    def random_job() -> str:
        return _faker.job()

    # ── payload factories ──────────────────────────────────────────────────

    @staticmethod
    def random_user_payload(role: str = "user") -> dict:
        """Return a dict suitable as a create-user request body."""
        payload = {
            "first_name": _faker.first_name(),
            "last_name":  _faker.last_name(),
            "email":      _faker.unique.email(),
            "phone":      _faker.phone_number(),
            "job":        _faker.job(),
            "role":       role,
        }
        logger.debug("FakerUtils.random_user_payload → %s", payload)
        return payload

    @staticmethod
    def random_address() -> dict:
        return {
            "street":  _faker.street_address(),
            "city":    _faker.city(),
            "state":   _faker.state(),
            "country": _faker.country(),
            "zip":     _faker.postcode(),
        }


# ── Run this file directly to see sample generated data ───────────────────
if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

    from utilities.logger import get_logger
    log = get_logger("__main__")

    log.info("=== FakerUtils direct run ===")
    fu = FakerUtils()
    log.info("random_name()         → %s", fu.random_name())
    log.info("random_email()        → %s", fu.random_email())
    log.info("random_phone()        → %s", fu.random_phone())
    log.info("random_uuid()         → %s", fu.random_uuid())
    log.info("random_job()          → %s", fu.random_job())
    payload = fu.random_user_payload(role="admin")
    log.info("random_user_payload() → %s", payload)
    log.info("=== Done ===")
