"""
utilities/logger.py
────────────────────
Central logging setup.

HOW IT WORKS
────────────
• This module calls setup_logging() at the very bottom, the instant it is
  imported by anyone — Robot test, plain Python script, or unit test.
• Every other module does:
      from utilities.logger import get_logger
      logger = get_logger(__name__)
  That single line guarantees logging is always configured before the first
  log message is written, regardless of how the file is run.

LOG FORMAT
──────────
  2024-01-15 12:34:56 | INFO     | core.api_client          | GET /users → 200
  <timestamp>         | <level>  | <module (25 chars wide)> | <message>

OUTPUT
──────
  Console  : always
  File     : reports/<env>.log  (path from config YAML, created if missing)
"""

import logging
import sys
from pathlib import Path

from config.config_loader import config

# ── guard: never add handlers twice ───────────────────────────────────────
_configured = False


def setup_logging() -> logging.Logger:
    """
    Configure the root Python logger from the active config YAML.
    Safe to call multiple times — only runs once due to _configured guard.
    Returns the root logger.
    """
    global _configured
    if _configured:
        return logging.getLogger()

    # Convert "DEBUG" / "INFO" / "WARNING" string → int constant
    numeric_level = getattr(logging, config.log_level.upper(), logging.INFO)

    # Single formatter shared by both handlers
    fmt = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)-25s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    root = logging.getLogger()
    root.setLevel(numeric_level)

    # ── console handler (stdout so it stays inline with Robot output) ──────
    if not any(isinstance(h, logging.StreamHandler) and h.stream is sys.stdout
               for h in root.handlers):
        console = logging.StreamHandler(sys.stdout)
        console.setLevel(numeric_level)
        console.setFormatter(fmt)
        root.addHandler(console)

    # ── file handler ────────────────────────────────────────────────────────
    log_path = Path(config.log_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)   # create reports/ if needed

    if not any(isinstance(h, logging.FileHandler) and
               getattr(h, 'baseFilename', None) == str(log_path.resolve())
               for h in root.handlers):
        file_handler = logging.FileHandler(log_path, mode="a", encoding="utf-8")
        file_handler.setLevel(numeric_level)
        file_handler.setFormatter(fmt)
        root.addHandler(file_handler)

    _configured = True

    root.info(
        "Logging initialised | env=%-4s | level=%-7s | file=%s",
        config.env, config.log_level, config.log_file,
    )
    return root


def get_logger(name: str) -> logging.Logger:
    """
    Return a named logger.
    Logging is guaranteed to be configured by the time this returns.

    Usage (in every module):
        from utilities.logger import get_logger
        logger = get_logger(__name__)
    """
    setup_logging()                  # no-op if already done
    return logging.getLogger(name)


# ── AUTO-BOOTSTRAP ─────────────────────────────────────────────────────────
# This runs the moment 'from utilities.logger import get_logger' appears
# anywhere — Python script, Robot suite, unit test, or interactive shell.
# No manual call to setup_logging() is needed anywhere else.
setup_logging()
