"""
core/api_client.py
───────────────────
Executes HTTP requests and wraps the result in a clean APIResponse object.

Features:
  • Timeout from config (one place to change)
  • Automatic token refresh on 401 (via TokenManager.invalidate + one retry)
  • Dynamic wait: poll until an expected status/condition is met
  • Structured logging for every request and response
"""

import time
import logging
from dataclasses import dataclass, field
from typing import Any, Callable

import requests

from config.config_loader import config
from core.token_manager import TokenManager
from core.header_manager import HeaderManager
from core.request_manager import RequestManager
from utilities.retry import retry_call
from utilities.logger import get_logger

logger = get_logger(__name__)


# ── response wrapper ───────────────────────────────────────────────────────

@dataclass
class APIResponse:
    """
    Thin wrapper around requests.Response with convenience properties.
    Passed back to every Robot keyword so tests never import requests directly.
    """
    status_code: int
    body:        dict | list | str     # parsed JSON or raw text
    headers:     dict
    elapsed_ms:  float
    url:         str
    method:      str
    raw:         Any = field(repr=False)   # original requests.Response

    @property
    def ok(self) -> bool:
        return 200 <= self.status_code < 300

    def json(self) -> dict | list:
        if isinstance(self.body, (dict, list)):
            return self.body
        raise ValueError("Response body is not JSON")

    def __str__(self) -> str:
        return (
            f"APIResponse({self.method} {self.url} → "
            f"{self.status_code} | {self.elapsed_ms:.0f}ms)"
        )


# ── client ─────────────────────────────────────────────────────────────────

class APIClient:
    """
    Executes HTTP requests built by RequestManager.

    Usage:
        client = APIClient()
        resp = client.send(method="GET", endpoint="/users/1")
        resp = client.send(method="POST", endpoint="/users", body={...})

        # Dynamic wait until 200 arrives (or timeout):
        resp = client.wait_until(
            method="GET", endpoint="/jobs/42",
            condition=lambda r: r.status_code == 200,
            timeout=30, interval=3,
        )
    """

    def __init__(self):
        self._token_manager  = TokenManager()
        self._header_manager = HeaderManager(self._token_manager)
        self._request_manager = RequestManager(self._header_manager)
        self._session = requests.Session()

    # ── main send ──────────────────────────────────────────────────────────

    def send(
        self,
        method: str,
        endpoint: str,
        body: dict | None = None,
        params: dict | None = None,
        extra_headers: dict | None = None,
        exclude_headers: list | None = None,
        auth: bool = True,
        allow_401_retry: bool = True,
    ) -> APIResponse:
        """
        Send an HTTP request.

        Args:
            method           : GET / POST / PUT / PATCH / DELETE
            endpoint         : Path e.g. "/users/123"
            body             : Request body dict (JSON-serialised automatically)
            params           : Query params dict
            extra_headers    : Merge on top of default headers
            exclude_headers  : Keys to drop from default headers
            auth             : Include Authorization header (default True)
            allow_401_retry  : On 401, invalidate token and retry once

        Returns:
            APIResponse
        """
        req = self._request_manager.build(
            method=method,
            endpoint=endpoint,
            body=body,
            params=params,
            extra_headers=extra_headers,
            exclude_headers=exclude_headers,
            auth=auth,
        )

        response = self._execute(req)

        # ── auto-refresh token on 401 ──────────────────────────────────
        if response.status_code == 401 and allow_401_retry and auth:
            logger.warning("401 Unauthorised — invalidating token and retrying once")
            self._token_manager.invalidate()
            req = self._request_manager.build(
                method=method, endpoint=endpoint, body=body,
                params=params, extra_headers=extra_headers,
                exclude_headers=exclude_headers, auth=auth,
            )
            response = self._execute(req)

        return response

    # ── dynamic wait ───────────────────────────────────────────────────────

    def wait_until(
        self,
        method: str,
        endpoint: str,
        condition: Callable[["APIResponse"], bool],
        timeout: int = 60,
        interval: int = 3,
        body: dict | None = None,
        params: dict | None = None,
        extra_headers: dict | None = None,
    ) -> APIResponse:
        """
        Poll the endpoint every `interval` seconds until `condition(response)`
        returns True, or until `timeout` seconds have elapsed.

        Args:
            condition : Lambda / function receiving APIResponse, returning bool.
                        e.g.  lambda r: r.status_code == 200
                              lambda r: r.json().get("status") == "completed"
            timeout   : Maximum seconds to wait.
            interval  : Seconds between polls.

        Returns:
            The last APIResponse where condition was True.

        Raises:
            TimeoutError if condition never becomes True within timeout.

        Example:
            resp = client.wait_until(
                "GET", "/jobs/42",
                condition=lambda r: r.json().get("status") == "done",
                timeout=60, interval=5,
            )
        """
        deadline = time.time() + timeout
        attempt  = 0

        logger.info(
            "Dynamic wait | %s %s | timeout=%ds interval=%ds",
            method.upper(), endpoint, timeout, interval,
        )

        while time.time() < deadline:
            attempt += 1
            resp = self.send(
                method=method, endpoint=endpoint,
                body=body, params=params, extra_headers=extra_headers,
            )
            logger.debug(
                "Wait poll #%d | status=%d | condition=%s",
                attempt, resp.status_code, condition(resp),
            )
            if condition(resp):
                logger.info(
                    "Condition met after %d poll(s) | %s", attempt, resp
                )
                return resp

            remaining = deadline - time.time()
            if remaining <= 0:
                break
            sleep_for = min(interval, remaining)
            logger.debug("Condition not met — sleeping %.1fs …", sleep_for)
            time.sleep(sleep_for)

        raise TimeoutError(
            f"[APIClient] Condition not met within {timeout}s "
            f"after {attempt} poll(s) on {method.upper()} {endpoint}"
        )

    # ── private ────────────────────────────────────────────────────────────

    def _execute(self, req: dict) -> APIResponse:
        method  = req["method"]
        url     = req["url"]
        headers = req["headers"]
        json_body = req.get("json")
        params    = req.get("params")

        logger.info("→ %s %s", method, url)
        if json_body:
            logger.debug("   body: %s", json_body)
        if params:
            logger.debug("   params: %s", params)

        start = time.time()
        try:
            raw = self._session.request(
                method  = method,
                url     = url,
                headers = headers,
                json    = json_body,
                params  = params,
                timeout = config.timeout,
            )
        except requests.exceptions.Timeout:
            logger.error("Request TIMED OUT after %ds | %s %s", config.timeout, method, url)
            raise
        except requests.exceptions.ConnectionError as exc:
            logger.error("Connection error | %s %s | %s", method, url, exc)
            raise

        elapsed_ms = (time.time() - start) * 1000

        # ── parse body ────────────────────────────────────────────────
        try:
            body = raw.json()
        except Exception:
            body = raw.text

        resp = APIResponse(
            status_code = raw.status_code,
            body        = body,
            headers     = dict(raw.headers),
            elapsed_ms  = elapsed_ms,
            url         = url,
            method      = method,
            raw         = raw,
        )

        log_fn = logger.info if resp.ok else logger.warning
        log_fn(
            "← %d %s | %s %s | %.0fms",
            resp.status_code,
            raw.reason or "",
            method,
            url,
            elapsed_ms,
        )
        if not resp.ok:
            logger.warning("   response body: %s", body)

        return resp


# ── Run this file directly to smoke-test the full client stack ────────────
if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

    from utilities.logger import get_logger
    log = get_logger("__main__")

    log.info("=== APIClient direct run ===")
    client = APIClient()
    log.info("APIClient initialised — TokenManager, HeaderManager, RequestManager all wired")
    log.info("Config active: env=%s | base_url=%s | timeout=%ds",
             __import__('config.config_loader', fromlist=['config']).config.env,
             __import__('config.config_loader', fromlist=['config']).config.base_url,
             __import__('config.config_loader', fromlist=['config']).config.timeout)
    log.info("To make a real call, point base_url in your YAML to a live API.")
    log.info("=== Done ===")
