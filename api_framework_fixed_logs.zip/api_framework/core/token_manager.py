"""
core/token_manager.py
──────────────────────
Responsible for ONE thing: give me a valid Bearer token.

Flow:
  1. If cached token is still valid  → return it immediately.
  2. Otherwise                       → POST to auth endpoint, cache, return.

All config (URL, credentials, timeout) is read from config/ so changing the
env changes everything automatically.
"""

import time
import logging

import requests

from config.config_loader import config
from utilities.logger import get_logger

logger = get_logger(__name__)


class TokenManager:
    """
    Fetches and caches an OAuth2 client-credentials token.

    Usage:
        tm = TokenManager()
        token = tm.get_token()        # returns plain string, e.g. "eyJhbGc..."
    """

    def __init__(self):
        self._token: str | None = None
        self._expires_at: float = 0.0          # epoch seconds
        self._buffer_seconds: int = 30         # refresh 30 s before actual expiry

    # ── public ─────────────────────────────────────────────────────────────

    def get_token(self) -> str:
        """
        Return a valid access token.
        Fetches a new one only when the cached token is expired (or missing).
        """
        if self._is_valid():
            logger.debug("Token cache HIT — reusing existing token (expires in %.0fs)",
                         self._expires_at - time.time())
            return self._token

        logger.info("Token cache MISS — fetching new token from %s", config.token_url)
        return self._fetch_token()

    def invalidate(self) -> None:
        """Force the next call to get_token() to re-fetch (useful after 401)."""
        logger.info("Token invalidated — will re-fetch on next request")
        self._token = None
        self._expires_at = 0.0

    # ── private ────────────────────────────────────────────────────────────

    def _is_valid(self) -> bool:
        return (
            self._token is not None
            and time.time() < (self._expires_at - self._buffer_seconds)
        )

    def _fetch_token(self) -> str:
        payload = {
            "grant_type":    config.grant_type,
            "client_id":     config.client_id,
            "client_secret": config.client_secret,
        }

        try:
            resp = requests.post(
                config.token_url,
                data=payload,
                timeout=config.timeout,
            )
            resp.raise_for_status()
        except requests.exceptions.RequestException as exc:
            logger.error("Token fetch FAILED: %s", exc)
            raise

        body = resp.json()

        self._token      = body["access_token"]
        expires_in       = int(body.get("expires_in", 3600))
        self._expires_at = time.time() + expires_in

        logger.info(
            "Token fetched successfully | expires_in=%ds | token_type=%s",
            expires_in,
            body.get("token_type", "Bearer"),
        )
        # Log only first/last 6 chars so secrets don't appear in logs
        masked = f"{self._token[:6]}...{self._token[-6:]}"
        logger.debug("Token (masked): %s", masked)

        return self._token


# ── Run this file directly to smoke-test token fetching ───────────────────
if __name__ == "__main__":
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

    from utilities.logger import get_logger
    log = get_logger("__main__")

    log.info("=== TokenManager direct run ===")
    tm = TokenManager()
    log.info("Calling get_token() for the first time ...")
    try:
        token = tm.get_token()
        log.info("Token received (masked): %s...%s", token[:6], token[-6:])
        log.info("Calling get_token() again — should be a cache HIT ...")
        token2 = tm.get_token()
        log.info("Cache HIT confirmed: same token = %s", token == token2)
    except Exception as exc:
        log.error("Token fetch failed (expected if no real API is running): %s", exc)
    log.info("=== Done ===")
