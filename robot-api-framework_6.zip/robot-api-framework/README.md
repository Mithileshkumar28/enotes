# Robot API Framework — Iron Mountain

## Structure

```
robot-api-framework/
├── config/
│   ├── qa.yml          ← default env
│   ├── dev.yml
│   ├── stg.yml
│   └── etg.yml
├── resources/
│   └── common_headers.resource   ← token fetch, shared headers, logging keywords
├── tests/
│   └── reports/
│       └── reports_test.robot
├── results/            ← auto-generated: log.html, report.html, output.xml, api_test.log
└── README.md
```

## Prerequisites

```bash
pip install -r requirements.txt
```

## Running Tests

### Default (QA env)
```bash
robot --outputdir results tests/
```

### Specific environment
```bash
robot --outputdir results -v ENV:dev tests/
robot --outputdir results -v ENV:stg tests/
robot --outputdir results -v ENV:etg tests/
```

### Run by tag
```bash
robot --outputdir results -i smoke tests/
robot --outputdir results -i GET tests/
robot --outputdir results -i negative tests/
```

## Token Generation (OAuth2)

Token is fetched **automatically** at Suite Setup via `Fetch OAuth2 Token`.
- Grant type: `client_credentials`
- Credentials come from the active env config yml (`client_id`, `client_secret`, `token_url`)
- Token is stored as `${BEARER_TOKEN}` suite variable and injected into every `Build Common Headers` call
- No manual token passing needed

## Logging

Two log outputs are generated after every run inside `results/`:

| File | Description |
|---|---|
| `report.html` | Robot's visual HTML report (pass/fail summary) |
| `log.html` | Robot's detailed HTML execution log |
| `output.xml` | Machine-readable result (CI/CD use) |
| `api_test.log` | Plain text log: timestamps, request/response, auth events |

### Sample `api_test.log` output
```
[2026-06-08 10:01:00] [CONFIG]   Loaded environment: qa | base_url: https://...
[2026-06-08 10:01:01] [AUTH]     Fetching token from: https://auth-qa.ironmountain.com/oauth2/token
[2026-06-08 10:01:01] [AUTH]     Token fetched successfully
[2026-06-08 10:01:02] [REQUEST]  GET https://.../phyrapi/companies/208275/reports
[2026-06-08 10:01:02] [REQUEST]  Headers: {'authorization': 'Bearer eyJ...', ...}
[2026-06-08 10:01:02] [RESPONSE] Status: 200
[2026-06-08 10:01:02] [RESPONSE] Body: [...]
```

## Common Headers Keywords

| Keyword | Purpose |
|---|---|
| `Load Environment Config` | Loads yml config for active ENV |
| `Fetch OAuth2 Token` | Calls token endpoint, stores Bearer token |
| `Build Common Headers` | Returns headers dict with auto-injected token |
| `Add Header` | Adds/overrides one header in a dict |
| `Remove Header` | Removes one header from a dict |
| `Log API Request` | Writes request details to api_test.log |
| `Log API Response` | Writes response details to api_test.log |

## Config File Structure

```yaml
base_url:      https://dxp10102-02-pdev2qa3.insight.ironmountain.com
company_id:    "208275"
solution_id:   "2e814851-9d3b-4227-b064-70ee9ae75797"
user_id:       user@ironmountain.com
token_url:     https://auth-qa.ironmountain.com/oauth2/token
client_id:     your-client-id
client_secret: your-client-secret
```
