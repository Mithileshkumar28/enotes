*** Settings ***
Library         RequestsLibrary
Library         Collections
Resource        ../../resources/common_headers.resource
Resource        ../../resources/token.resource

Suite Setup     Initialize Suite


*** Test Cases ***

GET Reports - Success
    [Documentation]    Verify GET /companies/{companyId}/reports returns 200
    [Tags]             reports    GET    smoke
    ${headers}=        Build Common Headers
    Log API Request    GET    ${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports    ${headers}
    ${response}=       GET
    ...                url=${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports
    ...                headers=${headers}
    ...                expected_status=200
    ...                verify=False
    Log API Response    ${response}
    Should Be Equal As Strings    ${response.status_code}    200

GET Reports - Unauthorized (No Token)
    [Documentation]    Verify GET /reports returns 401 when auth header is missing
    [Tags]             reports    GET    negative
    ${headers}=        Build Common Headers
    ${headers}=        Remove Header    ${headers}    authorization
    Log API Request    GET    ${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports    ${headers}
    ${response}=       GET
    ...                url=${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports
    ...                headers=${headers}
    ...                expected_status=any
    ...                verify=False
    Log API Response    ${response}
    Should Be Equal As Strings    ${response.status_code}    401

GET Reports - With Extra Custom Header
    [Documentation]    Verify GET /reports works when an extra header is added
    [Tags]             reports    GET    custom-header
    ${headers}=        Build Common Headers
    ${headers}=        Add Header    ${headers}    x-custom-header    test-value
    Log API Request    GET    ${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports    ${headers}
    ${response}=       GET
    ...                url=${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports
    ...                headers=${headers}
    ...                expected_status=200
    ...                verify=False
    Log API Response    ${response}
    Should Be Equal As Strings    ${response.status_code}    200

POST Report - Create New Report
    [Documentation]    Verify POST /companies/{companyId}/reports creates a report
    [Tags]             reports    POST
    ${headers}=        Build Common Headers
    ${body}=           Create Dictionary
    ...                reportName=Test Report
    ...                reportType=ASSET
    Log API Request    POST    ${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports    ${headers}    ${body}
    ${response}=       POST
    ...                url=${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports
    ...                headers=${headers}
    ...                json=${body}
    ...                expected_status=any
    ...                verify=False
    Log API Response    ${response}


*** Keywords ***

Initialize Suite
    [Documentation]    Load env config, fetch OAuth2 token, create shared session.
    Load Environment Config
    Fetch OAuth2 Token
    Create Session     iron_mountain    ${BASE_URL}    verify=False
