*** Settings ***
Documentation       Reports API Test Suite
...                 ENV default: qa  — override: --variable ENV:dev
...                 TOKEN         — override: --variable TOKEN:your_token

Library             RequestsLibrary
Library             Collections
Library             JSONLibrary
Resource            ../resources/common_headers.resource

Suite Setup         Initialize Suite


*** Variables ***
# Populated in Suite Setup from config.yml
${BASE_URL}         ${EMPTY}
${COMPANY_ID}       ${EMPTY}


*** Test Cases ***

GET Reports - Should Return 200
    [Documentation]    GET /phyrapi/companies/{companyId}/reports
    [Tags]             reports    smoke    GET
    ${response}=       GET
    ...                url=${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports
    ...                headers=${COMMON_HEADERS}
    ...                expected_status=200
    Log                ${response.json()}


GET Reports - Validate Response Is A List
    [Documentation]    Response body must be a JSON array
    [Tags]             reports    regression    GET
    ${response}=       GET
    ...                url=${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports
    ...                headers=${COMMON_HEADERS}
    ...                expected_status=200
    ${body}=           Set Variable    ${response.json()}
    Should Not Be Empty    ${body}    msg=Response body is empty


GET Reports - With Extra Custom Header
    [Documentation]    Adds a one-off header without changing the shared dict
    [Tags]             reports    custom-header    GET
    ${local_headers}=  Get Base Headers
    ${local_headers}=  Add Header    ${local_headers}    x-request-id    test-run-001
    ${response}=       GET
    ...                url=${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports
    ...                headers=${local_headers}
    ...                expected_status=200
    Log                ${response.json()}


GET Reports - Without content-type Header
    [Documentation]    Removes content-type for this request only
    [Tags]             reports    custom-header    GET
    ${local_headers}=  Get Base Headers
    ${local_headers}=  Remove Header    ${local_headers}    content-type
    ${response}=       GET
    ...                url=${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports
    ...                headers=${local_headers}
    ...                expected_status=200
    Log                ${response.json()}


POST Report - Create New Report
    [Documentation]    POST /phyrapi/companies/{companyId}/reports
    [Tags]             reports    regression    POST
    ${body}=           Create Dictionary
    ...                reportName=Test Report
    ...                reportType=CUSTOM
    ${response}=       POST
    ...                url=${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports
    ...                headers=${COMMON_HEADERS}
    ...                json=${body}
    ...                expected_status=any
    Log                Status: ${response.status_code}
    Log                Body:   ${response.text}


PUT Report - Update Existing Report
    [Documentation]    PUT /phyrapi/companies/{companyId}/reports/{reportId}
    [Tags]             reports    regression    PUT
    ${report_id}=      Set Variable    your-report-id-here
    ${body}=           Create Dictionary
    ...                reportName=Updated Report Name
    ${response}=       PUT
    ...                url=${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports/${report_id}
    ...                headers=${COMMON_HEADERS}
    ...                json=${body}
    ...                expected_status=any
    Log                Status: ${response.status_code}
    Log                Body:   ${response.text}


PATCH Report - Partial Update
    [Documentation]    PATCH /phyrapi/companies/{companyId}/reports/{reportId}
    [Tags]             reports    regression    PATCH
    ${report_id}=      Set Variable    your-report-id-here
    ${body}=           Create Dictionary
    ...                reportName=Patched Name
    ${response}=       PATCH
    ...                url=${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports/${report_id}
    ...                headers=${COMMON_HEADERS}
    ...                json=${body}
    ...                expected_status=any
    Log                Status: ${response.status_code}
    Log                Body:   ${response.text}


DELETE Report
    [Documentation]    DELETE /phyrapi/companies/{companyId}/reports/{reportId}
    [Tags]             reports    regression    DELETE
    ${report_id}=      Set Variable    your-report-id-here
    ${response}=       DELETE
    ...                url=${BASE_URL}/phyrapi/companies/${COMPANY_ID}/reports/${report_id}
    ...                headers=${COMMON_HEADERS}
    ...                expected_status=any
    Log                Status: ${response.status_code}
    Log                Body:   ${response.text}


*** Keywords ***

Initialize Suite
    [Documentation]    Loads env config once for the whole suite.
    ...                Sets suite-level variables BASE_URL, COMPANY_ID, COMMON_HEADERS.
    ${cfg}=            Load Env Config
    Set Suite Variable    ${BASE_URL}      ${cfg}[base_url]
    Set Suite Variable    ${COMPANY_ID}    ${cfg}[company_id]
    ${headers}=        Get Base Headers
    Set Suite Variable    ${COMMON_HEADERS}    ${headers}
    Log                Running against ENV=${ENV} → ${BASE_URL}
