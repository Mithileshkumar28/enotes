# Robot API Framework

Simple Robot Framework API test suite for Iron Mountain Insight APIs.

---

## Structure

```
robot-api-framework/
├── config/
│   └── config.yml                # env configs: dev | qa | stg | etg
├── resources/
│   └── common_headers.resource   # base headers + Add Header / Remove Header
├── tests/
│   └── reports_api.robot         # test cases
├── results/                      # auto-generated robot output
└── requirements.txt
```

---

## Setup

```bash
pip install -r requirements.txt
```

---

## Run Tests

### Default (QA env)
```bash
robot --variable TOKEN:your_bearer_token_here \
      --outputdir results \
      tests/reports_api.robot
```

### Switch environment
```bash
# DEV
robot --variable ENV:dev --variable TOKEN:your_token --outputdir results tests/reports_api.robot

# STG
robot --variable ENV:stg --variable TOKEN:your_token --outputdir results tests/reports_api.robot

# ETG
robot --variable ENV:etg --variable TOKEN:your_token --outputdir results tests/reports_api.robot
```

### Run by tag
```bash
# Only smoke tests
robot --variable TOKEN:your_token -i smoke --outputdir results tests/reports_api.robot

# Only GET tests
robot --variable TOKEN:your_token -i GET --outputdir results tests/reports_api.robot

# Exclude DELETE
robot --variable TOKEN:your_token -e DELETE --outputdir results tests/reports_api.robot
```

---

## How Headers Work

`common_headers.resource` provides three keywords:

| Keyword | What it does |
|---|---|
| `Get Base Headers` | Returns a fresh copy of all common headers |
| `Add Header` | Adds/overrides one key in a headers dict |
| `Remove Header` | Removes one key from a headers dict |

**Suite-level shared headers** — set once in `Initialize Suite`, reused across all tests via `${COMMON_HEADERS}`.

**Per-test custom headers** — call `Get Base Headers` locally, then `Add Header` / `Remove Header` without touching `${COMMON_HEADERS}`.

```robot
${local_headers}=  Get Base Headers
${local_headers}=  Add Header      ${local_headers}    x-request-id    abc-123
${local_headers}=  Remove Header   ${local_headers}    content-type
```

---

## Passing Token

Token is intentionally **not** stored in `config.yml` (security).  
Always pass it at runtime:

```bash
robot --variable TOKEN:eyJraWQiOi...  tests/reports_api.robot
```
